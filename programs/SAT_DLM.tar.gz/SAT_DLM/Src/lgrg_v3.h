/*
 * Copyright (C) 1997, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */


#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>

#define TRUE 1
#define FALSE 0
 
#define REAL int

#define MAX_NCOLS 40  

#define DESC_F 0                /* descent flag in the primary var space:
				   0   first-meet hill climbing
				   1   steepest hill climbing, gradient descent
				 */ 

#define DESC_O 1                /* descent order in the primary var space */
 
#define UPDATE_U_MODE  0        /* the mode of updating dual variables(u):
				   0:  u is updated every fixed interval 
				       (UPDATE_U_INT), by fixed amount (INC_U),
  				       and increase by MULTI*INC_U at local
				       minima.
				   1: u is only increase at local minima by
				      the minimal amount to erase this local
				      minima.
				 */
#define MULTI   1               /* the multiplier for stagnent stage */
#define UPDATE_U_INT  5000000   /* the interval of update u */

#define UPBOUND_U 0             /* the upper bound for dual variables:
				   0   no upper bound; o.w. the number 
				 */

#define SEED 101                /* seed for drand48 */		

#define WRONG_VAR_MODE 1        /* vars are selected from unsatified clauses */
	   
#define wrong_cl_list_l 1000    /* the length of the list with wrong clauses */

#define make(v) (((v)>0 && lgrg->prim_vars[v-1].value) || ((v<0) && !lgrg->prim_vars[-v-1].value))

typedef struct _var_str 
{
  short value;
  int diff;                     /* the difference of Lagrangian value when 
				   this var is flipped. + for improvement */
  int wc_diff;                  /* the difference of # of wrong clauses when
				   this var is flipped. + for improvement */ 
  int last_update;              /* the iteration # of last flip. 
				   used in tabu search   */
} var_str;

typedef struct lit_element {
  int lit;                      /* contains a lit OR the # of lits in following
clause  */
  int next;                     /* next clause containing the lit OR the weight
of the clause */
                                /*    lit:     #lits  lit1 lit2 lit3 ... */
                                /*    next:    weight c1   c2   c3   ... */
                                /* where c1 = index of start of next clause cont
aining */
                                /* lit1 or -lit1, etc. */
} *lit_element_ptr;

typedef struct _lgrgrec 
{
  int 	    nlits;		/* number of literals */
  int       rows;               /* number of clauses */
  int       columns;            /* number of columns */
  int       vars;               /* number of variables */
  int       aux_cols;           /* number of columns in the auxilary array */

/*  lit_element_ptr  body;         wff contains the clauses in the format */
                                /*    #lits, lit1, ..., litn */
                                /* First clause begins at index body[1]. */
                                /* size = nlits + rows + 1 */
  int 	    *body;              /* size = nlits + rows + 1, 
				   contains clauses: #lits, lit1, ..., litn */
  int       *row_base;          /* the base address of each row in body */

  int       *aux;               /* size = nlits + rows + 1 
				    contains entry: #clauses, c1, ..., cn 
				    for each variable */
  int       *aux_base;          /* the base address of each var in aux */

  var_str   *prim_vars;         /* vars: the primiry variables */
  int       n_impr_list;        /* the number of vars in the impr_list */
  int       *impr_list;         /* n_impr_list: vars that have a diff>0 */
  int       n_equal_list;       /* the number of vars in the equal_list */
  int       *equal_list;        /* n_equal_list: vars that have a diff=0 */
  int       diff_flag;          /* 1: on;  0 off */

  int       *in_wrong;          /* vars: whether the primary vars are in
				   wrong clauses;
				   0 not, 1 yes
				 */
  REAL      *dual_vars;         /* rows:    the dual variables for Lagrangian
				   methods
				 */
  char      *h;                 /* current value of satisfiabiliby of clauses*/

  REAL      cur_lgrg;           /* current lagragian value */
  int       wrong_clauses;      /* current number of wrong clauses */
  int       wrong_cl_list[wrong_cl_list_l]; 
                                /* the wrong clause list, maximum 100 */
  int       enable_wrong_cl_list;  /* this list is in effect */

  short     descent_f;          /* descent flag: 
				   0   hill-climbing
				   1   steepest hill-climbing
				 */
  short     descent_o;          /* descent order: the radius searched for 
				   improvement. 
				   1         order 1, 1 bit change;
				   others    not implement yet;
				 */

  REAL      infinite;           /* numerical stuff */

} lgrgrec;

void multi_start_rand(lgrgrec *lgrg);

lgrgrec *lgrg_init (FILE *fp, short verbose);
void print_lgrg(lgrgrec *lgrg, FILE *output);
void print_initial(lgrgrec *lgrg, FILE *output);

void set_init_points (lgrgrec *lgrg, int u);
void eval_h_value(lgrgrec* lgrg);
REAL eval_lagrangian(lgrgrec* lgrg);
REAL eval_wrong_clauses(lgrgrec* lgrg);

/* 1 if updated, 0 no update */
int update_x(lgrgrec* lgrg);
int update_x_det(lgrgrec* lgrg);
int update_x_sto(lgrgrec* lgrg);

int update_u(lgrgrec* lgrg, int inc);
int update_u2(lgrgrec* lgrg, int inc);
int update_u_diff(lgrgrec* lgrg, int inc);

void rand_perm(int n, int *list);

int pure01_1bit_best(lgrgrec* lgrg);

int pure01_1bit_hillclimb(lgrgrec* lgrg);
int pure01_1bit_hillclimb2(lgrgrec* lgrg);
int pure01_1bit_hillclimb_diff(lgrgrec* lgrg);
int pure01_1bit_hillclimb_sto(lgrgrec* lgrg, int *rand_list);
void check_lgrg(lgrgrec* lgrg);
void get_wrong_cl_list (lgrgrec *lgrg);

int eval_clause_1bit(lgrgrec *lgrg, int n, int m);
void remove_wrong_cl_list(lgrgrec* lgrg, int clause);
void insert_wrong_cl_list(lgrgrec* lgrg, int clause);

      
void may_remove_var_in_wrong(lgrgrec *lgrg, int key);
void	  insert_var_in_wrong(lgrgrec *lgrg, int key);

int random_0_to(int n);

/* for "diff" implementation */
void init_diff_struct (lgrgrec *lgrg);
void flip_update_diff(lgrgrec *lgrg, int var);
void insert_impr_list(lgrgrec *lgrg, int var);
void remove_impr_list(lgrgrec *lgrg, int var);
void print_impr_list(lgrgrec *lgrg);

void insert_equal_list(lgrgrec *lgrg, int var);
void remove_equal_list(lgrgrec *lgrg, int var);
void print_equal_list(lgrgrec *lgrg);

/* global variables */
int NEVALS;                   /* the number of evaluation of lagrangian
				 function in each round
			       */
int SAVE_POINT=0;
int NCOLS;
int MAX_IMPR_LIST;            /* the maximum length of the impr_list: 
			         nvars/1.5 */
int MAX_EQUAL_LIST;           /* the maximum length of the impr_list: 
			         nvars/1 */
int AUX_COLS;                 /* the width of aux array:
				 30*nrow/nvars  */
int diff_wc_flag;             /* whether the wrong clause list is invoked 
				 for the 'diff' impl.
				 0 not, 1 yes.
			       */
  
int debug_flag = 0;
int cur_iter;                 /* a global var with current iteration no */
int cur_enc;                  /* encumbent */

int global_last_update;       /* the index of last time entering flat region */
  
/* the following part is for collecting the profile. */
char f_lagr[20] = "Lagr.";    /* profile of Lagrangian values. every 
				 interval_lgrg save once       */
char f_lagr_tmp[20];
int  interval_lgrg = 1000;     
FILE *fp_lgrg;

char f_wc[20] = "WC.";        /* profile of Wrong Clause numbers.  every 
				 interval_lgrg save once.     */
char f_wc_tmp[20];
int  interval_wc = 1000;    
FILE *fp_wc;    

char f_uave[20]  = "UAVE.";   /* profile of average, min and max 
			         Lambda values */
char f_uave_tmp[20];          /* interval is the same as Lagr */
FILE *fp_uave;    

char f_u[20]  = "U.";         /* profile of Lambda values */
char f_u_tmp[20];
#define N_buckets  10
int  u_buckets[N_buckets];    /* Each bucket records the number of lambda
				 values in a range of 10. 
				 Eg. [0-10) [10-20), ..., 
				     u_buckets[ n/10 ] ++
			       */
int  interval_u = 10000;
FILE *fp_u;    

void print_profile(lgrgrec *lgrg, int iter, FILE *fp_lgrg, FILE *fp_wc, FILE *fp_u, FILE *fp_uave);

void reset_u (lgrgrec *lgrg);


/* Program input parameters */

int INIT_U;                   /* weight of objective */
int INC_U;                    /* weight of constraints */
int NITER;                    /* maximum number of iteration */
int NROUND;                   /* number of runs */
int tabu_len;                 /* the length of tabu list   */
int global_flat_limit;        /* maximum iterations spent in each flat region*/
int reset_count;              /* Lagrange multiplier reset interval */
float RESET_RATE;             /* Reduction rate of Lagrange multiplier */





char *copyright = "----------------------------------------------------------------------------
Copyright (C) 1997, Board of Trustees of the University of Illinois.\n
Permission is granted to copy and distribute source without fee.
Commercialization of this product requires prior licensing from the
University of Illinois.  Commercialization includes the integration of this
code in part or whole into a product for resale.  Free distribution of
unmodified source and use of this software is not considered
commercialization.
----------------------------------------------------------------------------\n";


