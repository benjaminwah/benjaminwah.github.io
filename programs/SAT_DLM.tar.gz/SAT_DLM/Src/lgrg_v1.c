/*
 * Copyright (C) 1997, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */

#include "lgrg_v1.h"

int main(int argc, char *argv[])
{
  lgrgrec *lgrg;
  FILE *fp; 
  
  printf("%s\n",copyright);

  /*
    if (argc != 2 && argc != 1) {
    printf("Usage: lgrg  inputfile.cnf or lgrg < inputfile.cnf\n");
    exit(-1);
    }

    if (argc == 2 ) {
    fprintf(stderr,"reading cnf file %s\n", argv[1]);
    fp = fopen(argv[1],"r");
    lgrg = lgrg_init(fp, TRUE);
    } else {
    fprintf(stderr,"reading cnf file from standard input\n");
    lgrg = lgrg_init(stdin, TRUE);
  }

  if (lgrg == NULL) {
    fprintf(stderr,"...reading cnf file failed\n");
    exit(-1);
  }  
  fclose(fp);
  */

  if (argc != 6) {
    printf("Usage: lgrg w_obj w_constr theta max_iter #runs < inputfile.cnf

  Input arguments:
  w_obj    -- integer (>= 0, e.g. 1), weight of objective
  w_constr -- integer(>= 1, e.g. 1), weight of constraints
  theta    -- integer (>= 1, e.g. 10),  control switching between two methods
  max_iter -- integer (>=1, e.g. 500000), maximum iterations to run
  #runs    -- integer (>=1, e.g. 1, or 10), number of runs 
           if #runs=1, the initial point is origin, 0;
           if #runs>1, initial points are randomly generated\n");
    exit(-1);
  }
  INIT_U = atoi(argv[1]);
  INC_U  = atoi(argv[2]);
  THETA  = atoi(argv[3]);
  NITER  = atoi(argv[4]);
  NROUND = atoi(argv[5]);

  printf("Weight of objective                     : %d
Weight of constraints                   : %d
Control parameter between two methods   : %d
Maximum number of iterations            : %d
Number of runs                          : %d\n",
	 INIT_U, INC_U, THETA, NITER, NROUND);
  if (NROUND==1) 
      printf("   (Starting from origin, 0)\n\n");
  else
      printf("   (Starting from randomly generated initial points)\n\n");

  lgrg = lgrg_init(stdin, FALSE);

  if (lgrg == NULL) {
    fprintf(stderr,"...reading cnf file failed\n");
    exit(-1);
  }  

  srand48(SEED);

  multi_start_rand(lgrg);
  
}

/* multi-start from randomly selected initial points */
void multi_start_rand(lgrgrec *lgrg)
{ 
  int iter, iterations, i, udx, udu, round, count;
  int encumbent, enci;
  REAL cur_obj, best_obj;
  struct tms t_buffer, old_t_buffer;
  int suc_time_s, suc_time_u, min_time_u, max_time_u, time_u, time_s;
  int aveevals = 0;
  int aveiter, miniter, maxiter;
  int avevalue = 0;

  aveiter = maxiter = max_time_u = 0;
  miniter = min_time_u = lgrg->infinite;

  times(&old_t_buffer);
  
  best_obj = lgrg->infinite;

  /* main body loop */
  for (count = suc_time_s = suc_time_u =  round=0; round < NROUND; round++) {

    NEVALS = 0; 
    encumbent = 100000;
    lgrg->enable_wrong_cl_list=0;

    fprintf(stdout, "\nRound %d\n", round);

    iterations = NITER;
    for (iter=0; iter<iterations; iter++) {
#ifdef DEBUG
/*      printf("iter %d, wrong cl %d, ture wrong cl %d, cur_lgrg %d, ture lgrg %d\n", iter, lgrg->wrong_clauses, eval_wrong_clauses(lgrg), lgrg->cur_lgrg, eval_lagrangian(lgrg)); */
      printf("iter %d, wrong cl %d, cur_lgrg %d\n", iter, lgrg->wrong_clauses,lgrg->cur_lgrg); 
#endif
      udx = update_x(lgrg);
#ifdef DEBUG
      printf("test var 3: %d\n", test_prim_vars(2)>0);
	check_lgrg(lgrg); 
#endif

      if(!(lgrg->wrong_clauses)){
	fprintf(stdout, "Lagrangian method finds feasible solution in %d iterations.\n", iter);
	count ++;
	best_obj = 0;

	times(&t_buffer);
	time_u = t_buffer.tms_utime - old_t_buffer.tms_utime;
	time_s = t_buffer.tms_stime - old_t_buffer.tms_stime;
	suc_time_s += time_s;
	suc_time_u += time_u;
	aveevals += NEVALS;
	aveiter += iter;
	if (iter < miniter)
	  miniter = iter;
	if (iter > maxiter)
	  maxiter = iter;
	if (min_time_u > time_u)
	  min_time_u = time_u;
	if (max_time_u < time_u)
	  max_time_u = time_u;
	break;
      }	else if (encumbent > lgrg->wrong_clauses) {
	encumbent = lgrg->wrong_clauses;	
	enci = iter;
#if defined DEBUG2||DEBUG
	fprintf(stderr, "enc: %d at %d iter\n", encumbent,iter);
#endif
      }

      if (!udx) {
	if (lgrg->enable_wrong_cl_list)
	  udu = update_u2(lgrg, MULTI*INC_U);
	else
	  udu = update_u(lgrg, MULTI*INC_U);  
      }
      else if  ((iter+1)%UPDATE_U_INT == 0 ) {
	if (lgrg->enable_wrong_cl_list)
	  udu = update_u2(lgrg, INC_U);
	else
	  udu = update_u(lgrg, INC_U);
      }
    }
    
    avevalue += lgrg->wrong_clauses;

    if (iter == iterations) 
      fprintf(stdout, "Maximum of %d iterations reached with best %d unsatisfied clause(s) at %d iter.\n", iter, encumbent,enci);
    
    if (lgrg->wrong_clauses < best_obj)
      best_obj = cur_obj;

    fprintf(stdout, "Final primary variable values (the first 30 variables): \n");
    for (i=0; i<lgrg->vars && i < 30; i++) {
      fprintf(stdout, "%d ", test_prim_vars(i)>0);
    }

    fprintf(stdout, "\nFinal Lagrange-multiplier values (the first 30 values): \n");
    for (i=0; i<lgrg->rows && i < 30; i++) 
      fprintf(stdout, "%d ", lgrg->dual_vars[i]);
    fprintf(stdout, "\n");

    
    set_init_points (lgrg, INIT_U);
    eval_h_value(lgrg);
    lgrg->cur_lgrg = eval_lagrangian(lgrg);
    lgrg->wrong_clauses = eval_wrong_clauses(lgrg);

    times(&t_buffer);
    fprintf(stdout, "In this round, user time %.3f sec, system time %.3f sec\n",
	    ((float) t_buffer.tms_utime - old_t_buffer.tms_utime)/60,
	    ((float) t_buffer.tms_stime - old_t_buffer.tms_stime)/60);
    
    old_t_buffer.tms_utime = t_buffer.tms_utime;
    old_t_buffer.tms_stime = t_buffer.tms_stime;
  }

  times(&t_buffer);
  fprintf(stdout, "\nBest solution in %d/%d successful rounds: %d unsatisfied clause(s)\n", count, NROUND, best_obj);
  if (count > 0) {
    fprintf(stdout, "Iterations/successful round: ave %.1f, min %d, max %d\n", ((float) aveiter)/count, miniter, maxiter);
    fprintf(stdout, "Time/successful round (sec): ave %.3f (user), %.3f (system); min %.3f, max %.3f\n",
	    ((float) suc_time_u)/60/count,((float) suc_time_s)/60/count,((float) min_time_u)/60,((float) max_time_u)/60);
  }
  fprintf(stdout, "Average time/round (w/ initialization): user time %.1f sec, system time %.1f sec\n",
	  ((float) t_buffer.tms_utime)/60/NROUND,((float) t_buffer.tms_stime)/60/NROUND);
}

/* read the problem into the lgrg structure */
lgrgrec *lgrg_init (FILE *fp, short verbose)
{
  short Debug;
  lgrgrec *lgrg;
  REAL **tmp_body;
  int i,j,k, count, max_len;
  int c, var;
  char kind[100];

  Debug = verbose;

  /* create lgrg structure */
  lgrg = (lgrgrec *) malloc (sizeof(lgrgrec));

  while (getchar()!='p'){
    while ((c = getchar()) != '\n'){
      if (c == EOF) { printf("Bad input\n"); exit(-1); }
    }
  }

  scanf("%s", kind);
  if (strcmp(kind, "cnf")) {
    fprintf(stderr, "Bad input\n"); 
    exit(-1);
  }

  lgrg->columns = NCOLS;
  lgrg->aux_cols = AUX_COLS;
  lgrg->vars = getint();
  lgrg->rows = getint();

  if (lgrg->rows > 64000) {
    fprintf(stdout,"Error: Due to specific data structuct implementation,
  this program cannot handle problems with more than 64000 clauses.
  This problem has %d clauses.\n", lgrg->rows);
    exit(-1);
  }

  /* added for automatically selecting the column size for body */
  tmp_body = (REAL **) malloc (lgrg->rows * sizeof(REAL *));
  for (i=0; i<lgrg->rows; i++)
    tmp_body[i] = (REAL *) malloc (MAX_NCOLS*sizeof(REAL));
			       
  for (max_len = i=0; i<lgrg->rows; i++) {
    count = 0;
    for (j=0; j<MAX_NCOLS; j++) 
      if (!(tmp_body[i][j] = getint())) {
	tmp_body[i][MAX_NCOLS-1] = count;
	if (max_len < count)
	  max_len = count;
	break;
      } else {
	count++;
	if (count >= MAX_NCOLS-1) {
	  printf("Error: Clause %d is longer than the maximum length, 
  MAX_NCOLS = %d, specified in lgrg_v1.h.\n", i, MAX_NCOLS);
	  exit(-1);
	}
      }
  }

  /* fprintf(stderr,"Max_col_len: %d\n", max_len); */
  /* end */
  lgrg->columns = max_len+2;

  lgrg->body = (short **) malloc ((lgrg->rows)*sizeof(short *));
  for (i=0; i<lgrg->rows; i++)
    lgrg->body[i] = (short *) malloc ((lgrg->columns)*sizeof(short));

  lgrg->aux = (short **) malloc ((lgrg->vars+1)*sizeof(short *));
  for (i=0; i<=lgrg->vars; i++) {
    lgrg->aux[i] = (short *) malloc ((lgrg->aux_cols)*sizeof(short));
    lgrg->aux[i][0] = 1;
  }

  for (i=0; i<lgrg->rows; i++) {
    for (j=0; j<lgrg->columns; j++) 
      if (!(lgrg->body[i][j] = tmp_body[i][j])) {
	lgrg->body[i][lgrg->columns-1] = tmp_body[i][MAX_NCOLS-1];
	break;
      } else {
	/* fill in lgrg->aux */
	var = abs(lgrg->body[i][j]);
	if (lgrg->aux[var][0] == lgrg->aux_cols-1) {
	  fprintf(stderr, "\nError: Variable %d appears in too many clauses. 
  The number of its appearance exceeds static space allocation. 
  This program cannot deal with appearence more than %d, unless
  the value for AUX_COLS in lgrg_v1.h is increased\n",
  var, lgrg->aux_cols-1);
	  exit (-1);
	} else {
	  lgrg->aux[var][lgrg->aux[var][0]] = i;
	  lgrg->aux[var][0]++;
	}
      }
  }

  for (i=0; i<lgrg->rows; i++)
    free(tmp_body[i]);
  free(tmp_body);			       
  
  lgrg->prim_vars = (lgrg->vars%int_l)? 
    (unsigned *) malloc ((lgrg->vars/int_l+1)*sizeof(unsigned)):
      (unsigned *) malloc ((lgrg->vars/int_l)*sizeof(unsigned));
    
  lgrg->dual_vars = (REAL *) malloc ((lgrg->rows)*sizeof(REAL));
  lgrg->h = (char *) malloc ((lgrg->rows)*sizeof(char));

  lgrg->infinite =  0x7fffffff;
  lgrg->enable_wrong_cl_list = 0;

  set_init_points (lgrg, INIT_U);

  eval_h_value(lgrg);
  lgrg->cur_lgrg = eval_lagrangian(lgrg);
  lgrg->wrong_clauses = eval_wrong_clauses(lgrg);

  lgrg->descent_f = 0; /* hillclimbing */
  lgrg->descent_f = DESC_F; /* steepest hillclimbing */
  lgrg->descent_o = DESC_O;

  if (Debug) 
    print_lgrg(lgrg, stdout);

  return lgrg;
}


/* print lgrg information for debug */
void print_lgrg(lgrgrec *lgrg, FILE *output) 
{
  int i,j;

  fprintf(output, "nvars %d, nclauses %d\n", lgrg->vars, lgrg->rows);
  for (j=0; j<lgrg->rows; j++) {
    for (i=0; i< lgrg->columns; i++) 
      if (lgrg->body[j][i] != 0) 
	fprintf(output, "%d ", lgrg->body[j][i]);
      else 
	break;
    fprintf(output,"\n");
  }
  
  print_initial(lgrg, output);
}

void set_init_points (lgrgrec *lgrg, int ini_u)
{
  int i;
  extern double drand48();

  if (NROUND ==1) { /* always starts from 0 */
      for (i=0; i<lgrg->vars/int_l; i++)
	  lgrg->prim_vars[i] = 0;
      if (lgrg->vars%int_l)
	  lgrg->prim_vars[i] = 0;
  } else {
      for (i=0; i<lgrg->vars/int_l; i++)
	  lgrg->prim_vars[i] = rint(drand48()* 0xffffffff);
      if (lgrg->vars%int_l)
	  lgrg->prim_vars[i] = rint(drand48()* 0xffffffff);
  }

  for (i=0; i<lgrg->rows; i++)
    lgrg->dual_vars[i] = ini_u;
}
  

/* print inital values */
void print_initial (lgrgrec *lgrg, FILE *output)
{
  int i;
  fprintf(output, "\nInitial values --- Primary vars: ");
  for (i=0; i<lgrg->vars; i++)
    fprintf(output, " %d", test_prim_vars(i)>0);
  fprintf(output,"\n");
}


/* given primary variable values x,
   return function value h.

   h(x):  h(x) =  0       if satisfied
               =  1       if not
*/
void eval_h_value(lgrgrec* lgrg)
{
  int i,j, tmp;

  for (j=0; j< lgrg->rows; j++) {
    lgrg->h[j] = 1;
    for (i=0; i<lgrg->columns; i++) {
      tmp = lgrg->body[j][i];
      if ( tmp > 0) {
	if (test_prim_vars(tmp-1)) {
	  lgrg->h[j] = 0;
	  break;
	}
      } else if (tmp < 0) {
	if (!test_prim_vars(-tmp-1)) {
	  lgrg->h[j] = 0;
	  break;
	}
      } else
	break;
    }
  }
}

 
/* given primary variable values x and dual variables u,
   return lagrangian function value l.

   l (x, u) = u h(x)
*/
REAL eval_lagrangian(lgrgrec* lgrg)
{
  REAL l;
  int i,j;

  NEVALS ++;

  l = 0;

  for (i=0; i<lgrg->rows; i++) 
    l += lgrg->dual_vars[i] * lgrg->h[i]; 
    
  return l;
}

/* the number of wrong clauses based on current assignment */
REAL eval_wrong_clauses(lgrgrec* lgrg)
{
  REAL l;
  int i,j;

  l = 0;
  for (i=0; i<lgrg->rows; i++) 
    if (lgrg->h[i])
      l ++; 
  return l;
}

/* given primary variable values x and dual variables u,
   update x along the gradient direction.

*/
int update_x(lgrgrec* lgrg)
{
  int i,j;
  int update;

  if (lgrg->descent_o != 1) {
    fprintf(stdout, "Descent order of %d has not been implemented.\n",
	    lgrg->descent_o);
    exit(-1);
  }

  if (lgrg->descent_f == 0)  {      /* stochastic hill-climbing */
    update = update_x_sto(lgrg);
  }
  else
    update = update_x_det(lgrg);

  return update;
}


/* update x in steep-descent manner */
int update_x_det(lgrgrec* lgrg)
{
  int i,j, k;
  REAL orig_l, current_l, best_l, best_v, save_value;
  int best_i, update;
  short *mark_l, count_mark, rec_mark[3], flag;

  mark_l = (short *) malloc (lgrg->columns * sizeof(short));
  for (i=0; i<lgrg->columns; i++) mark_l[i]=0;

  /* this is only for order of 1 */
  update = pure01_1bit_best(lgrg);

  return update;
}

/* update x in stochastic descent manner */
int update_x_sto(lgrgrec* lgrg)
{
  int i,j, update;
  
  if (lgrg->enable_wrong_cl_list || lgrg->wrong_clauses <= THETA) {
/*    update = pure01_1bit_best(lgrg); */
    if (!lgrg->enable_wrong_cl_list) {
      lgrg->enable_wrong_cl_list = 1;
      get_wrong_cl_list (lgrg);
    }
    update = pure01_1bit_hillclimb2(lgrg);
  }
  else
    update = pure01_1bit_hillclimb(lgrg);

  return update;
}

/* update x in stochastic descent manner */
int update_x_sto2(lgrgrec* lgrg)
{
  int i,j, update;
  int *rand_list;

  rand_list = (int *) malloc (lgrg->vars * sizeof(int));
  rand_perm(lgrg->vars, rand_list);

  /* this is only for order of 1 */
  update = pure01_1bit_hillclimb_sto(lgrg, rand_list);
  free(rand_list);

  return update;
}


/* given primary variable values x and dual variables u,
   update u along the h direction.

*/
int update_u(lgrgrec* lgrg, int inc)
{
  int i;

  if (UPBOUND_U) {
    for (i=0; i<lgrg->rows; i++) 
      if (lgrg->h[i] && lgrg->dual_vars[i]<UPBOUND_U) {
	lgrg->dual_vars[i] ++; 
      }
  } else
    for (i=0; i<lgrg->rows; i++) 
/*      if (lgrg->h[i]) {
	lgrg->dual_vars[i] ++; 
	lgrg->cur_lgrg ++;
      }
*/
      if (lgrg->h[i]) {
	lgrg->dual_vars[i] += inc; 
	lgrg->cur_lgrg += inc;
      }
  return 1;
}

/* take advantage of the wrong_cl_list */
int update_u2(lgrgrec* lgrg, int inc)
{
  int i, k, key;

  for (k=0; k<lgrg->wrong_clauses; k++) {
    key = lgrg->wrong_cl_list[k]; /* the clause */
    lgrg->dual_vars[key] += inc; 
    lgrg->cur_lgrg += inc;
  }
  return 1;
}
    

/* generate a random permutation of numbers
   0, 1, ..., n-1
*/

void rand_perm(int n, int *list)
{
  int i,j,a;
  extern double drand48();

  for (i=0; i<n; i++) list[i] = -1;

  for (i=0; i<n; i++) {
    a = floor(drand48()*n);
    if (list[a] < 0)
      list[a] = i;
    else {
      for (j = a+1;1; j++) {
	if (j >= n) j = 0;
	if (list[j] < 0) {
	  list[j] = i;
	  break;
	}
	if (j==a) {
	  fprintf(stdout, "Error: infinite loop!\n");
	  exit(-1);
	}
      }
    }
  }

/* for debug 
  printf("Random list: ");
  for (i=0; i<n; i++) 
    printf(" %d ", list[i]);
  printf("\n");
*/
}

/* for pure 0-1 IP problems, find the best in 1-bit neighbourhood.
   input: x, u
	   return update;
	   
*/
int pure01_1bit_best(lgrgrec* lgrg)
{
  int i, j, k;
  REAL old_l, new_l, best_l;
  int start;
  int update, best_i, clause, temp, old_wrong;
  int flag;
  int count = 0;

  update = 0; 
  old_l = best_l = lgrg->cur_lgrg;

  for (i=0; i<lgrg->vars; i++) {
    flag = 0;
    for (j=1; j<lgrg->aux[i+1][0]; j++) {   
      clause = lgrg->aux[i+1][j];
      if (lgrg->h[clause]) {
	flag = 1;
	break;
      }
    }
    if (!flag)
      continue;
  
    new_l = old_l;
    /* flip one bit of x */
    for (j=1; j<lgrg->aux[i+1][0]; j++) {   
      clause = lgrg->aux[i+1][j];
      new_l += (eval_clause_1bit(lgrg, clause, i+1) - lgrg->h[clause]) *
	lgrg->dual_vars[clause];
    }

    if (new_l < best_l) {
      best_l = new_l;
      best_i = i;
    }
  }

  if (best_l == old_l)
    return 0;
  else {
    lgrg->cur_lgrg = new_l;
    old_wrong = lgrg->wrong_clauses;
    for (j=1; j<lgrg->aux[best_i+1][0]; j++) { 
      clause = lgrg->aux[best_i+1][j]; 
      temp = eval_clause_1bit(lgrg, clause, best_i+1);
      lgrg->wrong_clauses += temp - lgrg->h[clause];

      lgrg->h[clause] = temp;
    }
    flip_prim_vars(best_i);
  }
} 

/* for SAT problems, find the first improvement in 1-bit neighbourhood.
   input: x, u, h (in lgrg), cur_l
   output: new x, new h
	   return update;
*/
int pure01_1bit_hillclimb(lgrgrec* lgrg)
{
  int i, j, k;
  REAL old_l, new_l;
  int start;
  int update, best_i, clause, temp, old_wrong;
  int flag, side_f, side_i, side_l;
  int count = 0;
  float dir;
  extern double drand48();

  side_f= 1;
  update = 0; 
  old_l = lgrg->cur_lgrg;

#ifdef SAVE_P
  i = start = SAVE_POINT;
  for (k=0; k<lgrg->vars; k++) {
    i = (i+1)%lgrg->vars;
#else
  dir = drand48();
  i = start = rint(drand48() * lgrg->vars);
  for (k=0; k<lgrg->vars; k++) {
    if (dir >0.5)
      i = (i+lgrg->vars-1)%lgrg->vars;
    else
      i = (i+1)%lgrg->vars;
#endif
  
    flag = 0;
    for (j=1; j<lgrg->aux[i+1][0]; j++) {   
      clause = lgrg->aux[i+1][j];
      if (lgrg->h[clause]) {
	flag = 1;
	break;
      }
    }
    if (!flag)
      continue;

    new_l = old_l;
    /* flip one bit of x */
    for (j=1; j<lgrg->aux[i+1][0]; j++) {   
      clause = lgrg->aux[i+1][j];
      if (lgrg->h[clause])
	new_l += -lgrg->dual_vars[clause];
      else {
	if (eval_clause_1bit(lgrg, clause, i+1))
	  new_l += lgrg->dual_vars[clause];
      }
    }
    
    if (new_l < old_l) {
      update = 1;
      lgrg->cur_lgrg = new_l;
      old_wrong = lgrg->wrong_clauses;
      for (j=1; j<lgrg->aux[i+1][0]; j++) { 
	clause = lgrg->aux[i+1][j]; 
	if (lgrg->h[clause]) {
	  lgrg->wrong_clauses--;
	  lgrg->h[clause] = 0;
	} else {
	  temp = eval_clause_1bit(lgrg, clause, i+1);
	  lgrg->wrong_clauses += temp;
	  lgrg->h[clause] = temp;
	}
      }
      flip_prim_vars(i);

#ifdef SAVE_P
      SAVE_POINT = i+1;
#endif

#ifdef DEBUG
      printf("  after %d flips, ", k+1);
      printf("fliping var %d from %d gives lgrg %d and wrong bit %d impr\n", i+1, !(test_prim_vars(i)), old_l-new_l, old_wrong - lgrg->wrong_clauses );
#endif     
      break;    
    }
#ifdef SIDEWALK
    else if (side_f && new_l == old_l) {
      side_f = 0;
      side_i = i;
    }
#endif

  }

#ifdef SIDEWALK
  if (!update && !side_f) {
/*    update = 1;  */
    old_wrong = lgrg->wrong_clauses;
    for (j=1; j<lgrg->aux[side_i+1][0]; j++) { 
      clause = lgrg->aux[side_i+1][j]; 
      temp = eval_clause_1bit(lgrg, clause, side_i+1);
      lgrg->wrong_clauses += temp - lgrg->h[clause];
      
      lgrg->h[clause] = temp;
    }
    flip_prim_vars(side_i);
#ifdef SAVE_P
      SAVE_POINT = side_i+1;
#endif

  }
#endif    
    
  return update;
}

/* for SAT problems, find the best improvement for the first wrong clauses
   in 1-bit neighbourhood.
	   return update;
*/
int pure01_1bit_hillclimb2(lgrgrec* lgrg)
{
  int i, j, k, index;
  int update, best_i, clause, temp, old_wrong;
  int impr, maximpr, maximprx, x, key;
  extern double drand48();
  

  update = 0; 
  maximpr = 10000000;
/*
#ifdef SAVE_P
  index = SAVE_POINT;
#else
  index = rint(drand48() * lgrg->wrong_clauses);
#endif
*/

  index = rint(drand48() * lgrg->wrong_clauses);
  for (k=0; k<lgrg->wrong_clauses; k++) {
    index = (index+1)%lgrg->wrong_clauses;
    key = lgrg->wrong_cl_list[index];     /* the clause */
    for (i=0; i<lgrg->columns; i++) {
      x = abs(lgrg->body[key][i]);
      impr = 0;
      if(!x)	break;
      /* flip one bit of x */
      for (j=1; j<lgrg->aux[x][0]; j++) {   
	clause = lgrg->aux[x][j];
	if (lgrg->h[clause])
	  impr += -lgrg->dual_vars[clause];
	else
	  impr += eval_clause_1bit(lgrg, clause, x)  *
	    lgrg->dual_vars[clause];
      }
    
      if (impr < 0) 
	break;

      if (impr < maximpr) {
	maximpr = impr;
	maximprx = x;
      }
    }

    if (impr < 0) 
      break;
  }

  if (impr < 0) {
    lgrg->cur_lgrg += impr;
    old_wrong = lgrg->wrong_clauses;
    for (j=1; j<lgrg->aux[x][0]; j++) { 
      clause = lgrg->aux[x][j]; 
      if (lgrg->h[clause]) {
	remove_wrong_cl_list(lgrg, clause);
	lgrg->wrong_clauses --;
	lgrg->h[clause] = 0;
      } else if (eval_clause_1bit(lgrg, clause, x)) {
	  lgrg->wrong_clauses ++;
	  lgrg->h[clause] = 1;
	  insert_wrong_cl_list(lgrg, clause);
	}
    }
    flip_prim_vars(x-1);

/*
#ifdef SAVE_P
      SAVE_POINT = key;
#endif
*/
    return 1;
  } 

/*
  if (UPDATE_U_MODE ==1) {
    update_u2(lgrg, maximpr+2);
#ifdef DEBUG
    printf("local min, increase u by %d\n", maximpr+2);
#endif
    return 1;
  }
*/

/*
#ifdef SIDEWALK
  if (maximpr > 0)
    return 0;

  lgrg->cur_lgrg += maximpr;
    old_wrong = lgrg->wrong_clauses;
    for (j=1; j<lgrg->aux[maximprx][0]; j++) { 
      clause = lgrg->aux[maximprx][j]; 
      if (lgrg->h[clause]) {
	remove_wrong_cl_list(lgrg, clause);
	lgrg->wrong_clauses --;
	lgrg->h[clause] = 0;
      } else if (eval_clause_1bit(lgrg, clause, maximprx)) {
	  lgrg->wrong_clauses ++;
	  lgrg->h[clause] = 1;
	  insert_wrong_cl_list(lgrg, clause);
	}
    }
    flip_prim_vars(maximprx-1);
#endif
*/
  return 0;
}

    


/* for SAT problems, find the first improvement in 1-bit neighbourhood.
   input: x, u, h (in lgrg), cur_l
   output: new x, new h
	   return update;
*/
int pure01_1bit_hillclimb_sto(lgrgrec* lgrg, int *rand_list)
{
  int i, j, k;
  REAL old_l, new_l;
  int update, best_i, clause;
  int count = 0;

  update = 0; 
  old_l = lgrg->cur_lgrg;

  for (k=0; k<lgrg->vars; k++) {
    i = rand_list[k];
    new_l = old_l;
    /* flip one bit of x */
    for (j=1; j<lgrg->aux[i+1][0]; j++) {   
      clause = lgrg->aux[i+1][j];
      new_l += (eval_clause_1bit(lgrg, clause, i+1) - lgrg->h[clause]) *
	lgrg->dual_vars[clause];
    }
    
    if (new_l < old_l) {
      update = 1;
      lgrg->cur_lgrg = new_l;
      for (j=1; j<lgrg->aux[i+1][0]; j++) {   
	clause = lgrg->aux[i+1][j];
	lgrg->h[clause] = eval_clause_1bit(lgrg, clause, i+1);
      }
      flip_prim_vars(i);
      
      break;
    }
  }
  return update;
}


int getint()
{
    int x;
    if (scanf("%d", &x)!=1){
	fprintf(stdout, "Error: Bad input\n"); 
	exit(-1);
    }
    return x;
}

/* evaluate the n'th clause with the m'th variable fliped
   return whether the clause is satisfied (0) or not (1).
*/
int eval_clause_1bit(lgrgrec *lgrg, int n, int m)
{
  int i, tmp;

  for (i=0; i<lgrg->columns; i++) {
    tmp = lgrg->body[n][i];
    if (tmp > 0) {
      if ( tmp == m) {
	if (!test_prim_vars(m-1)) 
	  return 0;
      } else {
	if (test_prim_vars(tmp-1))
	return 0;
      }
    } else if (tmp < 0) {
      if (-tmp == m) {
	if (test_prim_vars(m-1)) 
	  return 0;
      } else if (!test_prim_vars(-tmp-1))
	return 0;
    } else
      return 1;
  }
  return 1;
}
  
 
void check_lgrg(lgrgrec* lgrg)
{
  int i, j, tmp, value, tmp2;
  
  for (j=0; j< lgrg->rows; j++) {
    value = 1;
    for (i=0; i<lgrg->columns; i++) {
      tmp = lgrg->body[j][i];
      if ( tmp > 0) {
	if (test_prim_vars(tmp-1)) {
	  value = 0;
	  break;
	}
      } else if (tmp < 0) {
	tmp2 = test_prim_vars(-tmp-1);
	if (!test_prim_vars(-tmp-1)) {
	  value = 0;
	  break;
	}
      } else
	break;
    } 
    if (value != lgrg->h[j]) {
      printf("Something wrong in evaluate h in row %d.\n",j);
      for (i=0; i<lgrg->columns; i++) {
	tmp = lgrg->body[j][i];
	if (tmp ==0)
	  break;
        if (tmp > 0) 
	  printf(" %d (%d) ", tmp, test_prim_vars(tmp-1)>0);
	else 
	  printf(" %d (%d) ", tmp, test_prim_vars(-tmp-1)>0);
      }
      
      printf("\n");
      exit (-1);
    }
  }
}

void get_wrong_cl_list (lgrgrec *lgrg)
{
  int i,j;

  for (i=j=0; j< lgrg->rows; j++) {
    if (lgrg->h[j]) {
      lgrg->wrong_cl_list[i] = j;
      i++;
      if (i>wrong_cl_list_l) {
	printf("Error: wrong_cl_list_l = %d defined in lgrg_v1.h is not long enough.\n", wrong_cl_list_l);
	exit (-1);
      }
    }
  }
}

void remove_wrong_cl_list(lgrgrec* lgrg, int clause)
{
  int i, j;

#ifdef DEBUG
  printf("remove %d from w.c.l (wrong_clauses %d)\n", clause, lgrg->wrong_clauses);
#endif

  for (i=0; i<lgrg->wrong_clauses; i++)
    if (lgrg->wrong_cl_list[i] == clause) {
      for (j=i; j<lgrg->wrong_clauses-1; j++) 
	lgrg->wrong_cl_list[j] = lgrg->wrong_cl_list[j+1];
      break;
    }

  if (i >= lgrg->wrong_clauses) {
    printf("Wrong!\n");
    exit(-1);
  }
}
    
void insert_wrong_cl_list(lgrgrec* lgrg, int clause)
{
  int i, j;

#ifdef DEBUG
  printf("insert %d in w.c.l (wrong_clauses %d)\n", clause, lgrg->wrong_clauses);
#endif
  if (lgrg->wrong_clauses >= wrong_cl_list_l) {
    printf("Error: wrong_cl_list_l = %d defined in lgrg_v1.h is not long enough.\n", wrong_cl_list_l);
    exit(-1);
  }
  lgrg->wrong_cl_list[lgrg->wrong_clauses-1] = clause;
}
    
