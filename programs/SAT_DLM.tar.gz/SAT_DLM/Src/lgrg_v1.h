/*
 * Copyright (C) 1997, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */

/* main head file of the Lagrangian method for SAT

   by Yi Shang, 7-12-95
 
*/  

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>

#define TRUE 1
#define FALSE 0
 
#define REAL int
/* these definition is used for bit representation of primary variables using
   32 bit long unsigned int */
#define int_l 32
#define flip_prim_vars(i) (lgrg->prim_vars[(i)>>5] ^= 0x1 << ((i)&0x1f))
#define test_prim_vars(i) (lgrg->prim_vars[(i)>>5] & (0x1<<((i)&0x1f)))



#define MAX_NCOLS 40  

#define AUX_COLS  600 

#define DESC_F 0                /* descent flag in the primary var space:
				   0   first-meet hill climbing
				   1   steepest hill climbing, gradient descent
				 */ 

#define DESC_O 1                /* descent order in the primary var space */
 
#define UPDATE_U_MODE  0        /* the mode of updating dual variables(u):
				   0:  u is updated every fixed interval 
				       (UPDATE_U_INT), by fixed amount (INC_U),
  				       and increase by MULTI*INC_U at local
				       minima.
				   1: u is only increase at local minima by
				      the minimal amount to erase this local
				      minima.
				 */
#define MULTI   2               /* the multiplier for stagnent stage */
#define UPDATE_U_INT  500000      /* the interval of update u */

#define UPBOUND_U 0             /* the upper bound for dual variables:
				   0   no upper bound; o.w. the number 
				 */

#define SEED 101                /* seed for drand48 */		

#define WRONG_VAR_MODE 1        /* vars are selected from unsatified clauses */
	   
#define wrong_cl_list_l 1000    /* the length of the list with wrong clauses */

typedef struct _lgrgrec 
{
  int       rows;               /* number of clauses */
  int       columns;            /* number of columns */
  int       vars;               /* number of variables */
  int       aux_cols;           /* number of columns in the auxilary array */

  short     **body;             /* rows x columns matrix */
  short     **aux;              /* (vars+1) x aux_cols matrix */
	/* NOTE: number of clause must < 64k */
  unsigned      *prim_vars;         /* vars: the primiry variables */
  int       *in_wrong;          /* vars: whether the primary vars are in
				   wrong clauses;
				   0 not, 1 yes
				 */
  REAL      *dual_vars;         /* rows:    the dual variables for Lagrangian
				   methods
				 */
  char      *h;                 /* current value of satisfiabiliby of clauses*/

  REAL      cur_lgrg;           /* current lagragian value */
  int       wrong_clauses;      /* current number of wrong clauses */
  int       wrong_cl_list[wrong_cl_list_l]; 
                                /* the wrong clause list, maximum 100 */
  int       enable_wrong_cl_list;  /* this list is in effect */

  short     descent_f;          /* descent flag: 
				   0   hill-climbing
				   1   steepest hill-climbing
				 */
  short     descent_o;          /* descent order: the radius searched for 
				   improvement. 
				   1         order 1, 1 bit change;
				   others    not implement yet;
				 */

  REAL      infinite;           /* numerical stuff */

} lgrgrec;

void multi_start_rand(lgrgrec *lgrg);

lgrgrec *lgrg_init (FILE *fp, short verbose);
void print_lgrg(lgrgrec *lgrg, FILE *output);
void print_initial(lgrgrec *lgrg, FILE *output);

void set_init_points (lgrgrec *lgrg, int u);
void eval_h_value(lgrgrec* lgrg);
REAL eval_lagrangian(lgrgrec* lgrg);
REAL eval_wrong_clauses(lgrgrec* lgrg);

/* 1 if updated, 0 no update */
int update_x(lgrgrec* lgrg);
int update_x_det(lgrgrec* lgrg);
int update_x_sto(lgrgrec* lgrg);

int update_u(lgrgrec* lgrg, int inc);
int update_u2(lgrgrec* lgrg, int inc);

void rand_perm(int n, int *list);

int pure01_1bit_best(lgrgrec* lgrg);

int pure01_1bit_hillclimb(lgrgrec* lgrg);
int pure01_1bit_hillclimb2(lgrgrec* lgrg);
int pure01_1bit_hillclimb_sto(lgrgrec* lgrg, int *rand_list);
void check_lgrg(lgrgrec* lgrg);
void get_wrong_cl_list (lgrgrec *lgrg);

int eval_clause_1bit(lgrgrec *lgrg, int n, int m);
void remove_wrong_cl_list(lgrgrec* lgrg, int clause);
void insert_wrong_cl_list(lgrgrec* lgrg, int clause);

      
void may_remove_var_in_wrong(lgrgrec *lgrg, int key);
void	  insert_var_in_wrong(lgrgrec *lgrg, int key);

int random_0_to(int n);

/* global variables */
int NEVALS;                   /* the number of evaluation of lagrangian
				 function in each round
			      */
int SAVE_POINT=0;
int NCOLS;

/* Program input parameters */

int INIT_U;                   /* weight of objective */
int INC_U;                    /* weight of constraints */
int THETA;                    /* threshold of switching between two methods */
int NITER;                    /* maximum number of iteration */
int NROUND;                   /* number of runs */


char *copyright = "----------------------------------------------------------------------------
Copyright (C) 1997, Board of Trustees of the University of Illinois.\n
Permission is granted to copy and distribute source with out fee.
Commercialization of this product requires prior licensing from the
University of Illinois.  Commercialization includes the integration of this
code in part or whole into a product for resale.  Free distribution of
unmodified source and use of this software is not considered
commercialization.
----------------------------------------------------------------------------\n";


