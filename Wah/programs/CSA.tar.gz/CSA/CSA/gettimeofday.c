#ifdef V10
#include "sys/types.h"
#include "sys/timeb.h"

 void
gettimeofday_(long *tp, long *tzp)
{
	struct timeb tb;

	ftime(&tb);
	tp[0] = tb.time;
	tp[1] = tb.millitm;
	tzp[0] = tb.timezone;
	tzp[1] = tb.dstflag;
	}
#else
#include "sys/time.h"

 void
gettimeofday_(long *tp, long *tzp)
{
	struct timeval tb;
	struct timezone tz;

	gettimeofday(&tb, &tz);
	tp[0] = tb.tv_sec;
	tp[1] = tb.tv_usec;
	tzp[0] = tz.tz_minuteswest;
	tzp[1] = tz.tz_dsttime;
	}
#endif

 long
times_(long *b)
{ return times(b); }

