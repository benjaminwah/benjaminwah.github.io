#!/usr/bin/perl

$SOLVER = 0;           # 0-CSA      1-CSAGA
$DISMIX = 1;           # 0-discrete 1-mixed( need change user.f in sifdir) 
$mPen = 0;          # 0-CSA     1-static    2-dynamic   3-adaptive

 
$sifdir = "/home/manip1/chen/Software/SIFproblem/";  # SIF problem files
$csadir = "/home/manip1/chen/Software/Penalty+SA/";        # CSA package
$bindir = "/home/manip1/chen/Software/Penalty+SA/db/";     # executable & input


if($mPen == 0) {
   $resultdir = "/home/manip1/chen/Software/Results/ORpaper/";
   $suffix = ".csa.res"; 
} 
elsif($mPen == 1) {
   $resultdir = "/home/manip1/chen/Software/Results/ORpaper/";
   $suffix = ".static.res"; 
} 
elsif($mPen == 2) {
   $resultdir = "/home/manip1/chen/Software/Results/ORpaper/";
   $suffix = ".dynamic.res"; 
} 
elsif ($mPen == 3){
   $resultdir = "/home/manip1/chen/Software/Results/ORpaper/";
   $suffix = ".adaptive.res"; 
} else {
    exit;
}

 
$optbin = "salSIF";                 # anytime CSA binary compiled     
$orig_input = "in08";               # Tao Wang's input file          
$inputfile  = "anyin";              # input file to CSA
    
$jobfile = "ORpaper";
      
open( JOBF, $jobfile ) or dienice ("Can't open $jobfile !1");
@jobdata = <JOBF>;
close(JOBF);

foreach $probID (@jobdata) {
    chomp($probID);
    print "\n**********  Solving $probID ***********\n\n"; 
    $resultfile = join("", $resultdir, $probID, $suffix);
    solve_one_problem();        # parameters: ( $probID, $resultfile )
}

exit(0);  # End of main


sub solve_one_problem {

 # 1. initialize the SIF problem
 chdir "$sifdir" || die "can't cd to $sifdir !\n"; 
 system("initSIF $probID");


 # 2. compile and link the anytime-CSA code
 chdir "$csadir" || die "can't cd to $csadir !\n";
 system("genSIFrun");

 
 # 3. solve the problem and record results
 chdir "$bindir" || die "can't cd to $bindir !\n";
 getInput();
 system("$optbin < $inputfile > $resultfile");

 # 4. return back 
 chdir "$csadir" || die "can't cd to $csadir !\n"; 

}


sub getInput {
    local( $objscale );

#    open( ORIGINF, $orig_input ) || die "cannot open $orig_input !\n";
#    $objscale = <ORIGINF>;         # get the first line
#    close(ORIGINF);
#    chomp($objscale);

    open( INF, ">$inputfile" ) || die "cannot open $inputfile !\n"; 

#    print INF "$objscale\n";  # Objective scale factor  
    print INF "0\n";          # no lancelot  
    print INF "1\n";          # Objective scale factor  
    print INF "3\n";          # Langragian 
    print INF "0\n";    # 0-CSA  1-CSAGA
    print INF "$mPen\n";          # 0-CSA,1-static,2-dynamic
    print INF "0\n";          # Multi-level CSA/(0,1)
    print INF "1\n";          # Multi-start 0/1
    print INF "20\n";          # number of runs
    print INF "0.95\n";          # rT
    
    close(INF);
}
