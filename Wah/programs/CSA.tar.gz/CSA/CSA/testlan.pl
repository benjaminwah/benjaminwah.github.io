#!/usr/local/bin/perl

$landir = "/home/manip1/chen/Software/LANCELOT/Problems/";  # LANCELOT
$sifdir = "/home/manip1/chen/Software/SIFproblem/";     # SIF 
$csadir = "/home/manip1/chen/Software/cSA+SQP/";         # CSA package
$bindir = "/home/manip1/chen/Software/cSA+SQP/db/";     # executable

#$resultdir = "/home/manip1/chen/Software/Results/SIFs/LAN_mix/"; 
#$suffix    = ".lan.mix.res";        
#$sumfile = "/home/manip1/chen/Software/Results/SIFs/LAN_mix/summary.lan.mix";
#$sumfile = "/home/manip1/chen/Software/Results/SIFs/LAN_mix/unsol.summary.lan.mix";
 
$resultdir = "/home/manip1/chen/Software/Results/SIFs/LAN_dis/";
#$suffix    = ".lan.dis.res";
$suffix    = ".res";
#$sumfile = "/home/manip1/chen/Software/Results/SIFs/LAN_dis/summary.lan.dis";
$sumfile = "/home/manip1/chen/Software/Results/SIFs/LAN_dis/unsol.summary.lan.dis";

   
$optbin = "salSIF";                 # test binary compiled     
$inputfile  = "testlanin";        
    
$jobfile = "SIFlist";
      
open( JOBF, $jobfile ) or die "Can't open $jobfile !1";
@jobdata = <JOBF>;
close(JOBF);

foreach $probID (@jobdata) {
    chomp($probID);
    print "\n**********  Testing $probID ***********\n\n"; 
    $resultfile = join("", $resultdir, $probID, $suffix);
    solve_one_problem();        # parameters: ( $probID, $resultfile )
    $resline = lastline();
    open(SUMF, ">>$sumfile") or die "Can't open $sumfile !1";
    print SUMF "$probID $resline\n";
    close(SUMF); 
}

exit(0);  # End of main


sub solve_one_problem {

 # 1. Use Lancelot to solve it and record solution
 chdir "$landir" || die "can't cd to $landir !\n"; 
 system("fill $probID");

 # 2. initialize the SIF problem
 chdir "$sifdir" || die "can't cd to $sifdir !\n";
 system("initSIF $probID");

 # 3. compile and link the anytime-CSA code
 chdir "$csadir" || die "can't cd to $csadir !\n";
 system("genSIFrun");

 
 # 4. solve the problem and record results
 chdir "$bindir" || die "can't cd to $bindir !\n";
 system("$optbin < $inputfile > $resultfile");

 # 5. return back 
 chdir "$csadir" || die "can't cd to $csadir !\n"; 

}

sub lastline {
    local($line, @data);
      
    open( INF, $resultfile ) or die "fail";
    @data = <INF>;
    close(INF);
      
    foreach $line (@data) {
      chomp($line);        # get the last line
      if($line =~ /&/) { 
         return $line; 
      }
    }
}  
