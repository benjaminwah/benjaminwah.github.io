#include <stdio.h>
#include <stdlib.h>

main()
{
    int n, nh, ng, i, nrun, k, method;
    char fname[20], sname[20];
    FILE *fp, *fopen();

    printf("Input method (0 - cSA/ 1 - SQP) = ");
    scanf("%d",&method);
    if(method == 0) {
        printf("Input #runs = ");
        scanf("%d",&nrun);

        srand(123);
        for(i=1; i<=nrun; i++) {
           k=rand() % 10000;
           sprintf(fname,"input%d",i);
           if((fp=fopen(fname,"w")) == NULL) {
              printf("can not creat file %s\n",fname);
              exit(1);
           }
           fprintf(fp,"3\n0\n0\n1\n1\n%d\n0.8\n",k);
           fclose(fp);
        }

        printf("Input script file name = ");
        scanf("%s",sname);
        if((fp=fopen(sname,"w")) == NULL ) {
            printf("can not creat script file %s\n",sname);
            exit(1);
        }
        fprintf(fp,"#!/bin/tcsh\n\n");
        fprintf(fp,"limit cputime 10\n\n");
        for(i=1; i<=nrun; i++) {
            sprintf(fname,"input%d",i);
            if(i==1) 
                fprintf(fp,"echo \"%d-th run: Obj\" >! tt\n",i);
            else
                fprintf(fp,"echo \"%d-th run: Obj\" >> tt\n",i);
            fprintf(fp,"../sal_4.3 < %s >> tt \n", fname);
        }
        fclose(fp);
        return;
    }

    printf("Input #variables, #equality, #inequality = ");
    scanf("%d%d%d",&n,&nh,&ng);
    printf("Input #runs = ");
    scanf("%d",&nrun);
    
    srand(123);
    for(i=1; i<=nrun; i++) {
       k=rand() % 10000;
       sprintf(fname,"input%d",i);
       if((fp=fopen(fname,"w")) == NULL) {
          printf("can not creat file %s\n",fname);
          exit(1);
       }
       fprintf(fp,"%d\n%d\n%d\n%d\n",n,nh,ng,k);
       fclose(fp);
    }

    printf("Input script file name = ");
    scanf("%s",sname);
    if((fp=fopen(sname,"w")) == NULL ) {
        printf("can not creat script file %s\n",sname);
        exit(1);
    }
    fprintf(fp,"#!/bin/tcsh\n\n");
    fprintf(fp,"limit cputime 2\n\n");
    for(i=1; i<=nrun; i++) {
        sprintf(fname,"input%d",i);
        if(i==1) 
            fprintf(fp,"echo \"%d-th run: Obj\" >! tt\n",i);
        else
            fprintf(fp,"echo \"%d-th run: Obj\" >> tt\n",i);
        fprintf(fp,"../exe < %s >> tt \n", fname);
    }
    fclose(fp);
}
