/*
 * Copyright (C) 2000, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */
/*
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- 
#  Author: Zhe Wu, University of Illinois              |
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include "public.h"
#include "utility.h"
#include "sat.h"

#ifdef RAND_1
#define INIT_RANDOM srand((2*(runs+3+TH_START_RUN)+1)*17)
#define GetRandomNum ((unsigned int)random())
#endif

#ifdef RAND_2
long seed;
#define INIT_RANDOM seed=-17; for (i=0;i<=19*(runs+TH_START_RUN);i++) ran2(&seed)
/* #define INIT_RANDOM seed=-(17* (2*runs+3+TH_START_RUN));ran2(&seed) */
#define GetRandomNum ((unsigned int) (ran2(&seed)*2097151.0))
#endif

#define MATCH 1
#define NOT_MATCH 0

#define FLIP_VAR 0
#define RECOMPUTE_VARDELTA 1 

#define MAX_TABU_LEN 100

#define lg_t int
#undef WANT_DEBUG

u_int TH_ROUND;
u_int TH_FLATMOVE_TIMES;
u_int TH_USE_PERORIODIC_SHAKE;
u_int TH_USE_DEC_TO_MAINTAIN_AVG;
u_int TH_SHAKE;
u_int TH_USE_DIV_TO_MAINTAIN_AVG;
u_int TH_SHAKE_In_AVG;
float TH_MAX_AVG;
u_int TH_WANT_AVGLAMDA;
u_int TH_FLIP_TIMES;
u_int TH_TABU_LEN;
u_int TH_RUNS;
u_int TH_START_RUN;
u_int TH_INIT_FIX;
u_int TH_WEIGHT;
float TH_DECREASE_FACTOR;
u_int TH_ORDINARY_INCREASE_FACTOR;
u_int TH_SPECIAL_INCREASE_FACTOR;
u_int TH_BFC;
u_int TH_OUTPUT_SOLUTION;
u_int TH_BASE_VALUE;
u_int TH_WANT_DEBUG;
u_int TH_PRINT;
u_int TH_DECREASE_FACTOR_IN_AVG;
u_int TH_USE_FALSE_SET;
u_int TH_REALLY_RUN;

u_int stepF;
u_int stepLambda;

int *clauseLen;
int clauseNum;
int varNum;
int totalLiteralNum;

lg_t Lg;
int bestClauseNum;

int correctFalseClauseNum;

int falseClauseNum;
int *falseClauseQ;
int *posInFalseClauseQ;

int *absLiteralBuf;
int *signLiteralBuf;
int **absClause;
int **clauseSign;

int *varLinkLen;
int **varLink;
int **varLinkSign;

int *x;
lg_t *varDelta;
int *isFixed;

lg_t *lambda;
int *matchedVar;
int *clauseWeight;

int **isVarMatched;

char fileName[80];

u_int totalFlipTime;
float secondsUsed;

bool reductable=FALSE;

double startUser,endUser,startSys,endSys;

int roundNum=0;

char* paraFileName;


bool GetLineFrom(FILE *fd, char *Line,int *length);
void GetNonBlankLineFrom(FILE *fd, char* Line, int *length)
{
again:
    if (GetLineFrom(fd,Line,length))
        if (length==0 || Line[0]=='#' || Line[0]==' ' || Line[0]=='\n') // it is a comment line or blank
            goto again;
    //printf("\nNB: %s",Line);
}


/************************************************************
 * GetLineFrom:
 * To read a line from a file handle, if there is something to read
 * then the return bool value will be TRUE, otherwise FASE
 * the length is the actual number of bytes of the line including 
 * the return
 */
bool GetLineFrom(FILE *fd, char *Line,int *length)
{
    int c=-1;
    int i=0;

    ASSERT(fd!=NULL && Line!=NULL);

    if (ferror(fd) || feof(fd))
        return FALSE;

    while ( c !='\n' && c!=0 )
    {
        c=fgetc(fd);
        Line[i++]=c;
        if (feof(fd))
        {
            i--;
            break;
        }
    }

    if (feof(fd) && i EQ 0)
        return FALSE;

    *length=i;
    Line[i++]=0;

    return TRUE;
}/*End of bool GetLineFrom(FILE *fd, char *Line,int *length)*/


// fscanf(fp,"%s",buffer); \
// fscanf(fp,"%s",buffer); /*skip the description*/ 

#define GET_FPARA(y) \
GetNonBlankLineFrom(fp,buffer,&lineLen); \
sscanf(buffer,"%f",&y); 

#define GET_PARA(x) \
GetNonBlankLineFrom(fp,buffer,&lineLen);\
sscanf(buffer,"%d",&x); 

#define GET_DPARA(x) \
GetNonBlankLineFrom(fp,buffer,&lineLen);\
sscanf(buffer,"%lf",&x); 


/*
 ***********************************************************
 * ReadPara: read the parameters from the file specified
 */
void ReadPara(char *fileName)
{
    FILE *fp;
    char buffer[300];
    int lineLen;
    int TH_CHECKPOINT;

    if ( (fp=fopen(fileName,"rt")) EQ NULL)
        ERROR("File %s doesnot exists!!!\n",fileName);

    GET_PARA(TH_ROUND);
    GET_PARA(TH_FLIP_TIMES);

    GET_PARA(TH_USE_FALSE_SET);

    GET_PARA(TH_USE_PERORIODIC_SHAKE);
    GET_PARA(TH_SHAKE);
    GET_FPARA(TH_DECREASE_FACTOR);

    GET_PARA(TH_DECREASE_FACTOR_IN_AVG);
    // A float
    GET_FPARA(TH_MAX_AVG);
    //printf("\nThe maximal avg lambda should be %f",TH_MAX_AVG);

    GET_PARA(TH_USE_DIV_TO_MAINTAIN_AVG);
    GET_PARA(TH_USE_DEC_TO_MAINTAIN_AVG);
    GET_PARA(TH_SHAKE_In_AVG);

    GET_PARA(TH_FLATMOVE_TIMES);
    GET_PARA(TH_TABU_LEN);

    GET_PARA(TH_WEIGHT);
    GET_PARA(TH_BASE_VALUE);
    GET_PARA(TH_ORDINARY_INCREASE_FACTOR);
    GET_PARA(TH_SPECIAL_INCREASE_FACTOR);

    GET_PARA(TH_WANT_AVGLAMDA);
    GET_PARA(TH_RUNS);
    GET_PARA(TH_START_RUN);
    GET_PARA(TH_INIT_FIX);
    GET_PARA(TH_BFC);
    GET_PARA(TH_OUTPUT_SOLUTION);
    GET_PARA(TH_WANT_DEBUG);
    GET_PARA(TH_PRINT);
    GET_PARA(TH_REALLY_RUN);
    GET_PARA(TH_CHECKPOINT);

    ASSERT(TH_CHECKPOINT EQ 8888);
    ASSERT(TH_USE_DIV_TO_MAINTAIN_AVG+TH_USE_PERORIODIC_SHAKE + TH_USE_DEC_TO_MAINTAIN_AVG ==1);

    fflush(stdout);
    fclose(fp);
}/*End of ReadPara(char *fileName) */

/************************************************************
 *OutputSolution: after the solution is checked to be
 *    correct, then output it
 */
void OutputSolution(char *fileName,char *cnfName,int runs)
{
    FILE *fp;
    FILE *fp1;
    register int i;
    char name[80];
    int firstTime=0;
    char suffix[20];
    float flipTimes;

    char line[200];
    int lineLen;

    while (firstTime <=1 ) 
    {
        strcpy(name,fileName);
        strcpy(suffix,"");
        sprintf(suffix,"-%d",runs);
        strcat(name,suffix);

        if (firstTime EQ 1)
            strcat(name,".bak");

        firstTime++;

        if ((fp=fopen(name,"wt")) EQ NULL) 
            ERROR("\nFile create error!");

        if (correctFalseClauseNum EQ 0)
            fprintf(fp,"c solution found for %s\n",cnfName);
        else
            fprintf(fp,"c no solution found for %s\n",cnfName);

        flipTimes=(float)TH_FLIP_TIMES*roundNum;
        flipTimes=flipTimes+totalFlipTime;

        fprintf(fp,"c Remains fli : %15d \n",totalFlipTime);
        fprintf(fp,"c Total fli : %18.0f \n",flipTimes);
        fprintf(fp,"c Time used : %15.6f s\n",secondsUsed);
        fprintf(fp,"c Avg   fli : %15.6f s\n", secondsUsed/flipTimes);
        fprintf(fp,"c Best  FC# : %15d\n",bestClauseNum);
        fprintf(fp,"c Corr  FC# : %15d\n",correctFalseClauseNum);
        fprintf(fp,"c Total Rounds Used : %d \n",roundNum);

        if (reductable EQ TRUE)
            fprintf(fp,"c reductable\n");
        else
            fprintf(fp,"c Not reductable\n");

        fprintf(fp,"\nc -------------- Next are parameters -------- \n");
        fp1=fopen(paraFileName,"rt");
        if (fp1!=NULL);
        {
            while (GetLineFrom(fp1,line,&lineLen) EQ TRUE) 
                fprintf(fp,"%s",line);
            fclose(fp1);
        }
        fprintf(fp,"c -------------- End of parameters -------- \n");

        for (i=1;i<=varNum;i++)
            fprintf(fp,"%d %d\n",i,x[i]);

        fflush(fp);
        fclose(fp);
    }
}/*End of OutputSolution(char *fileName) */


/************************************************************
 *
 */
void DoReduction()
{
    register int i,j;
    int maxCLen; /*maximum clause length*/
    int cLen;    /*clause length*/
    int length;
    int fixedNumInC;
    int temp;
    int var;
    bool reduced;

    FILE* fixFile;
    int   fixVarId;
    int   fixVarValue;

    for (i=1;i<=varNum;i++)
        isFixed[i]=0;

    if (TH_INIT_FIX EQ 1)
    {
        fixFile=fopen("fixvariable","r");
        ASSERT(fixFile != NULL);

        fscanf(fixFile,"%d",&fixVarId);
        fscanf(fixFile,"%d",&fixVarValue);
        //DEBUG('*',"\nFix var %d at value %d",fixVarId,fixVarValue);
        fclose(fixFile);
        x[fixVarId]=fixVarValue;
        isFixed[fixVarId]=1;
    }

    maxCLen=0;
    for (i=1;i<=clauseNum;i++)
        if (clauseLen[i]>maxCLen)
            maxCLen=clauseLen[i];

#ifdef WANT_DEBUG
    printf("\nMax clauseLength is %d",maxCLen);
#endif

    length=0;
    while( (++length)<=maxCLen)
    {
        reduced=FALSE;
        for (i=1;i<=clauseNum;i++)
        {
            if (clauseLen[i] EQ length)
            {
                fixedNumInC=0;  
                for (j=1;j<=length;j++)
                {
                    var=absClause[i][j];
                    if (isFixed[var])
                    {
                        if (x[var] EQ clauseSign[i][j])
                            goto nextClause;
                        else
                            fixedNumInC++;
                    }
                }
                if (fixedNumInC EQ length-1)
                {
                    for (j=1;j<=length;j++)
                    {
                        var=absClause[i][j];
                        if (!isFixed[var])
                        {
#ifdef WANT_DEBUG    
                            // printf("\n Fixed var %d with %d in clause %d",
                            //   var,clauseSign[i][j],i);
#endif
                            isFixed[var]=1;
                            x[var]=clauseSign[i][j];
                            reduced=TRUE;
                            goto nextClause;
                        }
                    }
                }
            }
nextClause:
            temp=0; 
        } /*End of for (i=1;...) */

        if (reduced EQ TRUE)
            length=0;
    } /*End of while() */ 
}/*End of DoReduction() */


/************************************************************
 * ReadFile:read the cnf from the data file
 */
int ReadFile(char * fileName)
{
    FILE *fp;
    char line[200];
    int  lineLen;

    int  tempVarNum;
    int  tempClauseNum;

    int  readVar;

    int i,j;
    int k;

    int literalIdx;
    int clauseIdx;

#ifdef WANT_DEBUG
    DEBUG('*',"\nFileName:%s",fileName);
#endif

    if((fp=fopen(fileName,"rt")) EQ NULL)
        ERROR("File %s doesnot exists!!!\n",fileName);

    /* i here is just to make sure the data file has correct format */
    i=0;
    Forever
    {
        if (GetLineFrom(fp,line,&lineLen) EQ TRUE) 
            if (line[0] EQ 'p') 
                break; 
        i++;

        if (i>100)
            ASSERT(FALSE);
    }
    sscanf(line+5,"%d %d",&tempVarNum,&tempClauseNum);

#ifdef WANT_DEBUG
    DEBUG('*',"\nThe var num is %d, clause Num is %d",
            tempVarNum,tempClauseNum);
#endif

    totalLiteralNum=0;
    for (i=0;i<tempClauseNum;i++)
    {
        fscanf(fp,"%d",&readVar);
        while(readVar!=0)
        {
            totalLiteralNum++; 
            fscanf(fp,"%d",&readVar);
        }
    } 

#ifdef WANT_DEBUG
    DEBUG('*',"\nTotal Literal Num is %d",totalLiteralNum);
#endif

    clauseNum=tempClauseNum;
    varNum   =tempVarNum;

    clauseLen     =(int *)malloc(S_INT*(clauseNum+2));
    absLiteralBuf =(int *)malloc(S_INT*(totalLiteralNum+2));
    signLiteralBuf=(int *)malloc(S_INT*(totalLiteralNum+2));

    absClause =(int **)malloc(sizeof(int*) *(clauseNum+2) );
    clauseSign=(int **)malloc(sizeof(int*) *(clauseNum+2) );

    ASSERT(clauseLen!=NULL && 
            absLiteralBuf !=NULL &&
            signLiteralBuf !=NULL &&
            absClause!=NULL &&
            clauseSign!=NULL);

    rewind(fp);

    /*skip the comments as before */
    i=0;
    Forever
    {
        if (GetLineFrom(fp,line,&lineLen) EQ TRUE) 
            if (line[0] EQ 'p') 
                break; 
        i++;
        if (i>100)
            ASSERT(FALSE);
    }

    literalIdx=0;
    clauseIdx=1;

    absClause[1] =(int *)&(absLiteralBuf[0]);
    clauseSign[1]=(int *)&(signLiteralBuf[0]);

    for (i=0;i<clauseNum;i++)
    {
        j=0;

        fscanf(fp,"%d",&readVar);
        while (readVar!=0)
        {
            absLiteralBuf[++literalIdx]=abs(readVar);
            if (readVar<0)
                signLiteralBuf[literalIdx]=0;
            else
                signLiteralBuf[literalIdx]=1;

            j++;
            fscanf(fp,"%d",&readVar);
        }
        clauseLen[clauseIdx++]=j;
        absClause[clauseIdx] =(int *)&(absLiteralBuf[literalIdx]);
        clauseSign[clauseIdx]=(int *)&(signLiteralBuf[literalIdx]);

        for (j=1;j<=clauseLen[clauseIdx-1]-1;j++)
            for (k=j+1;k<=clauseLen[clauseIdx-1];k++)
                if ( absClause[clauseIdx-1][k] EQ absClause[clauseIdx-1][j])
                    /* this clause looks like -X1 v X1 */
                {
#ifdef WANT_DEBUG
                    printf("\nIn clause %d, same exists!", clauseIdx-1);
#endif
                    reductable=TRUE;
                }
    }

    /* To make sure read correctly */ 

    /*
        for (i=1;i<=clauseNum;i++)
        {
        printf("\nC%d[",i);
        for (j=1;j<=clauseLen[i];j++)
        printf("%d ",(2*clauseSign[i][j]-1)*absClause[i][j]);
        }    
     */
    fclose(fp);   
}/* End of ReadFile(char * fileName)*/


/************************************************************
 *CheckSolution: To make sure the solution found is
 *               correct!
 */
bool CheckSolution()
{
    register int i,j;
    int check;
    int len;
    int falseNum=0;
    lg_t lgran=0;
    int matchedNum;
    int cLen;
    int linkLen;

    for(i=1;i<=clauseNum;i++)
    {
        check=0;
        len=clauseLen[i];

        for(j=1;j<=len;j++)
            if (x[absClause[i][j]] EQ clauseSign[i][j])
                check=1;

        if (check EQ 0)
        {
            falseNum++; 
            lgran+=lambda[i];
        }
    }
    correctFalseClauseNum=falseNum;

    //DEBUG('*',"\n\nCheck FC# is %d,lg is %d", falseNum,lgran);
    //DEBUG('*',"\nExec  FC# is %d,lg is %d", falseClauseNum,Lg);
    //DEBUG('*', "  tFlip %12d, Rounds %d",totalFlipTime,roundNum); 

    if (falseNum!=falseClauseNum)
    {
        DEBUG('*',"\nWRONG in false clause #!");
    }

    /*if (lgran!=Lg)
    {
        DEBUG('*',"\nWRONG in lgran!, lgran=%d , Lg=%d ",lgran,Lg);
        if (reductable EQ TRUE)
            DEBUG('*',", this CNF is reductable\n");
        else
            DEBUG('*',", this CNF is Not reductable\n");
    }*/

    for (i=1;i<=clauseNum;i++)
    {
        matchedNum=0;
        cLen=clauseLen[i];
        for (j=1;j<=cLen;j++)
            if (x[absClause[i][j]] EQ clauseSign[i][j])
                matchedNum++; 
        if (matchedNum!=matchedVar[i])
            DEBUG('*',"\nMatched Num not correct for Clause %d",i);
    }

    return TRUE;
}/*End of CheckSolution() */


/************************************************************
 * Init: allocat some buffer for several data structures
 */
void Init()
{
    register int i;

    x           =(int *)malloc(S_INT*(varNum+2));
    isFixed     =(int *)malloc(S_INT*(varNum+2));
    varDelta    =(lg_t *)malloc(sizeof(lg_t)*(varNum+2));

    matchedVar  =(int *)malloc(S_INT*(clauseNum+2));
    clauseWeight=(int *)malloc(S_INT*(clauseNum+2));
    lambda      =(lg_t *)malloc(sizeof(lg_t)*(clauseNum+2)); 

    falseClauseQ     =(int *)malloc(S_INT*(clauseNum+2));
    posInFalseClauseQ=(int *)malloc(S_INT*(clauseNum+2));

    ASSERT(x!=NULL && varDelta!=NULL && matchedVar!=NULL
            && lambda!=NULL && falseClauseQ!=NULL
            && posInFalseClauseQ !=NULL
            && clauseWeight !=NULL && isFixed!=NULL );
}/*End of Init()*/


/************************************************************
 *InitLink: for each variable, maintain a link for it
 *   inside the link, store the clause id which 
 *   contain that variable 
 */
void InitLink()
{
    register int i,j;
    int len;
    int varIdx;

    varLinkLen=(int *)malloc(S_INT*(varNum+2));

    ASSERT(varLinkLen!=NULL);

    for (i=1;i<=varNum;i++)
        varLinkLen[i]=0;

    for (i=1;i<=clauseNum;i++)
    {
        len=clauseLen[i];
        for (j=1;j<=len;j++)
            varLinkLen[absClause[i][j]]++; 
    }   

    varLink     =(int **)malloc( sizeof(int *)*(varNum+2) ); 
    varLinkSign =(int **)malloc( sizeof(int *)*(varNum+2) ); 
    isVarMatched=(int **)malloc( sizeof(int *)*(varNum+2) ); 

    ASSERT(varLink!=NULL && varLinkSign!=NULL &&
            isVarMatched!=NULL);

    for (i=1;i<=varNum;i++)
    {
        varLink[i]     =(int *)malloc(S_INT*(varLinkLen[i]+2));
        varLinkSign[i] =(int *)malloc(S_INT*(varLinkLen[i]+2));
        isVarMatched[i]=(int *)malloc(S_INT*(varLinkLen[i]+2));
        ASSERT(varLink[i]!=NULL && varLinkSign[i]!=NULL &&
                isVarMatched[i]!=NULL);
    }

    for (i=1;i<=varNum;i++)
        varLinkLen[i]=0;

    for (i=1;i<=clauseNum;i++)
    {
        len=clauseLen[i];
        for (j=1;j<=len;j++)
        {
            varIdx=absClause[i][j];
            varLinkLen[varIdx]++;
            varLink    [varIdx][ varLinkLen[varIdx] ]=i;
            varLinkSign[varIdx][ varLinkLen[varIdx] ]=
                clauseSign[i][j];
        }
    }
}/*End of InitLink() */


/************************************************************
 *CountMatchedVarNumInClause:to count the mathced varnum
 *   for each clause
 */
void CountMatchedVarNumInClause()
{
    register i,j;
    int len;

    falseClauseNum=0;
    Lg=0;

    for (i=1;i<=clauseNum;i++)
        matchedVar[i]=0;

    for (i=1;i<=varNum;i++)
    {
        len=varLinkLen[i];
        for (j=1;j<=len;j++)
        {
            if ( varLinkSign[i][j] EQ x[i] )
            {
                matchedVar[ varLink[i][j] ]++;
                isVarMatched[i][j]=MATCH;
            }
            else
                isVarMatched[i][j]=NOT_MATCH;
        }
    }

    for (i=1;i<=clauseNum;i++)
    {
        if (matchedVar[i] EQ 0) /*it is a false clause*/
        {
            falseClauseQ[++falseClauseNum]=i;
            posInFalseClauseQ[i]=falseClauseNum;
            Lg+=lambda[i];
        }
        else 
            /*a true clause is not in the Queue */
            posInFalseClauseQ[i]=0;
    }   

    //DEBUG('*',"\nInitially, %d false clauses and L %d",
    //        falseClauseNum,Lg);

}/*End of CountMatchedVarNumInClause() */


/************************************************************
 *InitVarDelta: 
 */
void InitVarDelta()
{
    register int i,j, tempVar;
    int len;

#if 0
    for (i=1;i<=varNum;i++)
    {
        varDelta[i]=0;
        len=varLinkLen[i];
        for (j=1;j<=len;j++)
        {
            if (isVarMatched[i][j] EQ MATCH)
            {
                if (matchedVar[ varLink[i][j] ] EQ 1)
                    varDelta[i]+=lambda[ varLink[i][j] ];
            }       
            else
            {
                if (matchedVar[ varLink[i][j] ] EQ 0)
                    varDelta[i]-=lambda[ varLink[i][j] ];
            }       
        }   
    }    
#else
    for (i=1;i<=varNum;i++)
        varDelta[i]=0;

    for (i=1;i<=clauseNum;i++)
    {
        if (matchedVar[i]>1) continue;

        len=clauseLen[i];

        if (matchedVar[i]==0)
        {
            for (j=1;j<=len;j++)
                varDelta[absClause[i][j]]-=lambda[ i ]; 
        }
        else
        {
            for (j=1;j<=len;j++)
            {
                tempVar=absClause[i][j];
                if (x[tempVar] EQ clauseSign[i][j])
                {
                    varDelta[ tempVar ]+=lambda[ i ]; 
                    goto nextIdx;
                }
            }
        }
nextIdx:
    }   
#endif
}/*End of InitVarDelta() */



/************************************************************
 *Main:main function
 */
int main(int argc, char *argv[])
{
    int status;
    if (argc < 4) 
    {
        printf("usage:\n   %s CNF Para Output\n",argv[0]);
        exit(1);
    }

    /*Read the CNF*/
    ReadFile(argv[1]);

    Init();

    InitLink();

    paraFileName=argv[2];
    ReadPara(paraFileName);

    status=Search(argc,argv);

    //DEBUG('*',"\nBye RETURN VALUE= %d !\n",status);
    
    return status;
}/*End of main(int argc, char *argv[]) */


/************************************************************
 * FlipVar: flip the 0-1 and update related data structures
 */
inline void FlipVar(int var)
{
    register int i,j;
    int linkLen;
    int cLen; /*clause len*/
    int clauseIdx;
    int tempVar;
    int counter;
    unsigned int nRand;

    totalFlipTime++;
    x[var]=!x[var];

    Lg+=varDelta[var];

    varDelta[var]=0;

    linkLen=varLinkLen[var];

    for (i=1;i<=linkLen;i++)
    {
        clauseIdx=varLink[ var ][i];
        if (isVarMatched[var][i] EQ NOT_MATCH)
        {
            isVarMatched[var][i]=MATCH;
            matchedVar[clauseIdx]++;

            if (matchedVar[clauseIdx] EQ 1)
                /*this clause change from false to true */
            {
                posInFalseClauseQ[falseClauseQ[falseClauseNum]]=
                    posInFalseClauseQ[clauseIdx];
                falseClauseQ[posInFalseClauseQ[clauseIdx]]=
                    falseClauseQ[falseClauseNum--]; 
                posInFalseClauseQ[ clauseIdx ]=0; // not false any more

                cLen=clauseLen[clauseIdx];
                for (j=1;j<=cLen;j++)
                    varDelta[absClause[clauseIdx][j]]+=
                        lambda[clauseIdx];
            }
            else if (matchedVar[clauseIdx] EQ 2)
                /*from 1->2*/
            {
                cLen=clauseLen[clauseIdx];
                for (j=1;j<=cLen;j++)
                {
                    tempVar=absClause[clauseIdx][j];
                    if (x[tempVar] EQ clauseSign[clauseIdx][j] 
                            && (tempVar!=var) )
                    {
                        varDelta[tempVar]-=lambda[clauseIdx];
                        goto out;
                    } 
                }
                //ASSERT(FALSE);
            }

        }/*NOT_MATCH*/
        else
        {
            /*original the var MATCH the clause*/
            isVarMatched[var][i]=NOT_MATCH;
            matchedVar[clauseIdx]--;
            if (matchedVar[clauseIdx] EQ 0)
            {
                /*change from true to false*/
                falseClauseQ[++falseClauseNum]=clauseIdx;
                posInFalseClauseQ[clauseIdx]=falseClauseNum;
                cLen=clauseLen[clauseIdx];
                for (j=1;j<=cLen;j++)
                    varDelta[absClause[clauseIdx][j]]-=
                        lambda[clauseIdx];
                // clauseWeight[clauseIdx]++;

            }
            else if (matchedVar[clauseIdx] EQ 1)
            {
                /*from 2 -> 1*/
                cLen=clauseLen[clauseIdx];
                for (j=1;j<=cLen;j++)
                {
                    tempVar=absClause[clauseIdx][j];
                    if (x[tempVar] EQ clauseSign[clauseIdx][j])
                    {
                        varDelta[tempVar]+=lambda[clauseIdx];
                        goto out;
                    }
                }
                //ASSERT(FALSE);
            } 
        }
out:   j=0;
    }/*(i=1 to linkLen)*/

}/*End of FlipVar(int var) */


/************************************************************
 *IncreaseLambda: increase the lambda of a clause
 *   to a new value (can be larger or less)
 *   ATTN: the clause should be unsatisfied
 */
void IncreaseLambda(int clauseIdx,lg_t newLambda)
{
    lg_t delta;
    register int i;
    int cLen;
    int varIdx;

    delta=newLambda-lambda[clauseIdx]; 

    cLen=clauseLen[clauseIdx];

    for (i=1;i<=cLen;i++)
    {
        varIdx=absClause[clauseIdx][i];
        varDelta[ varIdx ]-=delta;
    }

    lambda[clauseIdx]=newLambda;
    Lg+=delta;

}/*End of IncreaseLambda(int clauseIdx,lg_t newLambda)*/


/************************************************************
 *ChangeLambda: change the lambda of a clause and
 *   update related data structures
 *   ATTN: change lambda can be used for
 *         both satisfied or unsatisfied clauses
 */
inline void ChangeLambda(int clauseIdx,lg_t newLambda)
{
    lg_t delta;
    register int i;
    int cLen;

    delta=newLambda-lambda[clauseIdx]; 

    lambda[clauseIdx]=newLambda;

    cLen=clauseLen[clauseIdx];

    if (matchedVar[clauseIdx] EQ 0)
    {
        /*This clause is false */
        for (i=1;i<=cLen;i++)
            varDelta[ absClause[clauseIdx][i] ]-=delta;
        Lg+=delta;
    }
    else
    {
        if (matchedVar[clauseIdx] EQ 1)
            /*This clause only has one var that make true */
        {
            for (i=1;i<=cLen;i++)
            {
                if (x[ absClause[clauseIdx][i] ] EQ 
                        clauseSign[clauseIdx][i] )
                {
                    varDelta[ absClause[clauseIdx][i] ]+=
                        delta;  
                    return;
                }
            }
            //ASSERT(FALSE);
        }
    } 
}/*End of ChangeLambda(int clauseIdx,int newLambda) */


/************************************************************
 *Search: do the lagarangian search
 */
int Search(int argc, char *argv[])
{
    register int i,j;
    int var;
    int idx;
    int clauseIdx;
    int varIdx;
    int cLen;
    int flatMoveTimes;
    lg_t bestLg;
    lg_t oldLg;
    int oldFalseClauseNum;
    int steps;
    lg_t newLambda;

    int minDelta;
    int* varBuffer;

    int* clauseBuffer;

    int tabuQ[MAX_TABU_LEN];
    int tabuQIdx=0;
    int *isVarInTabuQ;
    int tempVar;

    int counter=0;
    FILE *fp, *newfp;

    FILE * badFile;

    int maxWeight;
    int idx1;
    int bug=1;

    int runs=-1;

    int tmp;

    unsigned int nRand;
    unsigned int avgWeight;

    FILE* evilFile;

    int lastPrint=0;
    
#define SIZE 1000
#define HISTORY_SIZE 10
    int falseNumArray[SIZE+1];
    int falseNumArrayIdx;
    char* distance;
    int distanceIdx;
    int numAdjustLambda;
#if 0 
    int* evilClauses;

    Not Used!!!

        evilClauses=(int *) malloc ( S_INT*(clauseNum+2));
    ASSERT(evilClauses!=NULL);

    for (i=1;i<=clauseNum;i++)
        evilClauses[i]=0;
#endif

    clauseBuffer=(int *) malloc ( S_INT *(clauseNum+2));
    ASSERT(clauseBuffer!=NULL);

    varBuffer=(int *) malloc( S_INT*(varNum+2));
    ASSERT(varBuffer!=NULL);

    distance=(char *) malloc( S_CHAR*(varNum+2)*HISTORY_SIZE+2 );
    ASSERT(distance!=NULL);

    newfp=fopen("improve","wt");
    ASSERT(newfp!=NULL);

    isVarInTabuQ=(int *) malloc ( S_INT*(varNum+2));
    ASSERT(isVarInTabuQ!=NULL);

    DoReduction();

    falseNumArrayIdx=0;
    distanceIdx=0;
startAgain:

    lastPrint=0;
    runs++;

    INIT_RANDOM;
    /*
        srand((2*(runs+3+TH_START_RUN)+1)*17);
     */

    /*Set initial lambda to 1 to include the objective */
    for (i=1;i<=clauseNum;i++)
        lambda[i]=1;

    for (i=1;i<=varNum;i++)
        isVarInTabuQ[i]=0;

    for (i=0;i<MAX_TABU_LEN;i++)
        tabuQ[i]=0;

    for (i=1;i<=varNum;i++)
        if (!isFixed[i])
        {
            nRand=GetRandomNum;
            x[i]=(nRand&1);
        }

    for (i=1;i<=clauseNum;i++)
        clauseWeight[i]=0;

    CountMatchedVarNumInClause();
    InitVarDelta();

    totalFlipTime=0;

    flatMoveTimes=0;
    steps=0;
    bestLg=Lg;
    bestClauseNum=falseClauseNum;

    fp=fopen("trace","wt");
    ASSERT(fp!=NULL);
    fprintf(fp,"%d %d\n",varNum,clauseNum);

    //DEBUG('*',"\nStart search");
    CheckSolution();

    get_cpu_time(&startUser,&startSys);
    numAdjustLambda=0;
nextRound:

    while(falseClauseNum>0 && totalFlipTime<TH_FLIP_TIMES) 
    {
        minDelta=100000;/*Set it a large initial value*/
        for (i=1;i<=falseClauseNum;i++)
        {
            clauseIdx=falseClauseQ[i];
            cLen=clauseLen[clauseIdx];
            for (j=1;j<=cLen;j++)
            {
                varIdx=absClause[clauseIdx][j];

                if ((varDelta[varIdx]>=0)&&(isVarInTabuQ[varIdx] EQ 1))
                    /*Var is in Tabu Queue */
                    continue;

                if (varDelta[varIdx]<=minDelta &&(!isFixed[varIdx]))
                {
                    if (varDelta[varIdx]<minDelta)
                        idx=-1;
                    idx++;
                    varBuffer[idx]=varIdx;
                    minDelta=varDelta[varIdx];
                }
            }
        }/* for i=1 to falseClauseNum */

        if ((minDelta >0) || (idx EQ -1) )
        {
            flatMoveTimes=TH_FLATMOVE_TIMES;

            for (i=1;i<=falseClauseNum;i++)
                clauseWeight[ falseClauseQ[i] ]++;
            goto step1;
        };

        nRand=GetRandomNum;
        idx=nRand%(idx+1);
        var=varBuffer[idx]; 

flip:
        oldFalseClauseNum=falseClauseNum;
        oldLg=Lg;

        /*The var is not in tabu list*/
        if ((TH_TABU_LEN >0) && (isVarInTabuQ[var] EQ 0))
        {
            tempVar=tabuQ[tabuQIdx];
            isVarInTabuQ[tempVar]=0;
            tabuQ[tabuQIdx]=var;
            isVarInTabuQ[var]=1;
            tabuQIdx=tabuQIdx+1;
            if (tabuQIdx>=TH_TABU_LEN)
                tabuQIdx=0;
        }


        FlipVar(var);
        
        if (! TH_REALLY_RUN)
        {
            int tSize;
            int flipTimes=TH_FLIP_TIMES*roundNum;
            flipTimes=flipTimes+totalFlipTime;
            
            if (flipTimes>20000)
            {
                falseNumArray[ falseNumArrayIdx ]=falseClauseNum;
                falseNumArrayIdx++;

                //if (flipTimes>120000)
                //    tSize=SIZE;
                //else
                //    tSize=SIZE/10;
                tSize=SIZE;

                if ( falseNumArrayIdx > tSize )
                {
                    int maxiLambda,maxiWeight;
                    int sumLambda,sumWeight,sumFalseClauseNum;
                    float avgLambda,avgWeight, avgFalseClauseNum;

                    int offset,sumDistance; 

                    offset=(distanceIdx%HISTORY_SIZE)*varNum;
                    for (i=1;i<=varNum;i++)
                    {
                        distance[offset]=(char)x[i];
                        offset++;
                    }

                    distanceIdx++;
                    sumDistance=0;
                    if (distanceIdx>HISTORY_SIZE)
                    {
                        offset=0;
                        for (i=0;i<HISTORY_SIZE*varNum;i++)
                        {
                            sumDistance+=abs((int)distance[i]-(int)x[ offset + 1]);
                            offset++;
                            if (offset>=varNum) offset=0;
                        }
                    }
                    else
                        sumDistance=-1;

                    maxiLambda=maxiWeight=0;
                    sumLambda=sumWeight=sumFalseClauseNum=0;
                    for (i=1;i<=clauseNum;i++)
                    {
                        sumLambda+=lambda[i];
                        sumWeight+=clauseWeight[i];
                        maxiLambda=max(maxiLambda, lambda[i]);
                        maxiWeight=max(maxiWeight, clauseWeight[i]);
                    }

                    avgLambda=(float)sumLambda/(float)clauseNum;
                    avgWeight=(float)sumWeight/(float)clauseNum;

                    for (i=0;i<falseNumArrayIdx;i++)
                        sumFalseClauseNum+=falseNumArray[i];

                    avgFalseClauseNum=(float)sumFalseClauseNum/(float)tSize;

                    printf("\nZZZ BFCN %d aFCN %.2f aLam %.6f mLam %d aWei %.6f mWei %d sDis %d ratio %.6f",
                            bestClauseNum, avgFalseClauseNum, avgLambda, maxiLambda, avgWeight, 
                            maxiWeight, sumDistance, (float)((float)numAdjustLambda/(float)tSize));
                    falseNumArrayIdx=0;
                    numAdjustLambda=0;
                }
            }
        }

        if (bestClauseNum>=falseClauseNum)
        {
            if (TH_WANT_DEBUG EQ 0)
            {
                if (bestClauseNum EQ falseClauseNum)
                    goto next;
            }

            if (bestClauseNum>falseClauseNum && falseClauseNum<12 )
            {
                bestClauseNum=falseClauseNum;
                //printf("\nBFC# %d, tFlip %12d, Rnds %d, SR %d  NR %d MR %d %s ", 
                //        falseClauseNum,totalFlipTime,roundNum,TH_START_RUN,
                //        runs+TH_START_RUN,TH_RUNS,argv[1]); 
                if (falseClauseNum<=TH_OUTPUT_SOLUTION)
                {
                    ASSERT(CheckSolution() EQ TRUE);
                    get_cpu_time(&endUser,&endSys);
                    //printf("\nCPU time consumed (not elapsed wall clock time) is %.3f sec\n",
                    //        endUser-startUser+endSys-startSys);

                    secondsUsed=(float)endUser-startUser+endSys-startSys;
                    OutputSolution(argv[3],argv[1],TH_START_RUN+runs);
                }
            }

            bestClauseNum=falseClauseNum;
        }

        /*
        // if (falseClauseNum <= bestClauseNum + 3)
        if (TH_WANT_DEBUG >= 2)
        {
            // if (falseClauseNum<=TH_BFC)
            if ( ((lastPrint++)%TH_PRINT) == 0)
            {
                printf("\nFC# %d ( ", falseClauseNum);
                if (falseClauseNum>=4)
                    printf(" c %d %d %d ... %d) ",falseClauseQ[1],
                            falseClauseQ[2],falseClauseQ[3],
                            falseClauseQ[falseClauseNum]);
                else
                {
                    printf("(");
                    for (i=1;i<=falseClauseNum;i++)
                        printf(" %d ",falseClauseQ[i]);
                    printf(")");
                }
            }
            // printf("  tFlip %12d, Rounds %d",totalFlipTime,roundNum); 
        } //End of TH_WANT_DEBUG
        */

next:
        if (Lg>=bestLg)
            /*It is now actually flat move or up move*/
            flatMoveTimes++;
        else 
        {
            /*going really down */
            flatMoveTimes=0;
            bestLg=Lg;
        }

step1:
        if (flatMoveTimes>=TH_FLATMOVE_TIMES)
        {
            flatMoveTimes=0;
            steps++;

            for (i=1;i<=falseClauseNum;i++)
            {
                clauseIdx=falseClauseQ[i];
                IncreaseLambda(clauseIdx,lambda[clauseIdx]+TH_ORDINARY_INCREASE_FACTOR);
            }   
            numAdjustLambda++;

            maxWeight=0;
            avgWeight=0;
            idx=-1;

            if (TH_USE_FALSE_SET)
            {
                for (i=1;i<=falseClauseNum;i++)
                {
                    clauseIdx=falseClauseQ[i];
                    avgWeight+=clauseWeight[clauseIdx];
                    if (clauseWeight[ clauseIdx ] >= maxWeight )
                    {
                        if (maxWeight < clauseWeight[ clauseIdx ])
                            idx=-1;
                        maxWeight=clauseWeight[ clauseIdx ];

                        idx++;
                        clauseBuffer[idx]=clauseIdx;
                    }   
                }   
                avgWeight=max(TH_BASE_VALUE,avgWeight/falseClauseNum);
            }
            else // if (! TH_USE_FALSE_SET)
            {
                for (i=1;i<=clauseNum;i++)
                {
                    avgWeight+=clauseWeight[i];
                    if (maxWeight<=clauseWeight[i])
                    {
                        maxWeight=clauseWeight[i];  // Include certain Randomness
                        // if (maxWeight<clauseWeight[i])
                        //    idx=-1;
                        idx++;
                        clauseBuffer[idx]=i;
                    }   
                }   
                avgWeight=max(TH_BASE_VALUE,avgWeight/clauseNum);
            }// end of if (TH_USE_FALSE_SET)

            if (maxWeight>avgWeight*TH_WEIGHT && (TH_SPECIAL_INCREASE_FACTOR > 0) )
            {
                nRand=GetRandomNum;
                idx1=(nRand%(idx+1));  
                clauseIdx=clauseBuffer[idx1];
                ChangeLambda(clauseIdx,lambda[clauseIdx]+TH_SPECIAL_INCREASE_FACTOR);
                bestLg=Lg;
            }
        }// end of if (flatMoveTimes>=TH_FLATMOVE_TIMES)

        if (TH_USE_PERORIODIC_SHAKE)
        {
            if (steps%TH_SHAKE EQ (TH_SHAKE-1))
            {
                int avgLambda,maxiLambda;
                steps=0;

                avgLambda=maxiLambda=0; 
#if 1
                for (i=1;i<=clauseNum;i++)
                {
                    // newLambda=max(1,(int)( (float)(lambda[i]-TH_DECREASE_FACTOR) ) );
                    newLambda=max(1,(int)( (float)(lambda[i]-TH_DECREASE_FACTOR) ) );
                    if (newLambda!=lambda[i])
                        ChangeLambda(i,newLambda);

                    if (TH_WANT_AVGLAMDA)
                    {
                        avgLambda+=newLambda;
                        maxiLambda=max(newLambda,maxiLambda);
                    }
                }
#else
                for (i=1;i<=clauseNum;i++) {
                    lambda[i]=max(1,(int)( (float)(lambda[i]-TH_DECREASE_FACTOR) ) );
                    if (TH_WANT_AVGLAMDA) {
                        avgLambda+=lambda[i];
                        maxiLambda=max(newLambda,maxiLambda); }
                }

                Lg=0;
                for (i=1;i<=falseClauseNum;i++)
                    Lg+=lambda[ falseClauseQ[i] ];
                InitVarDelta();
#endif
                bestLg=Lg;
                //if(TH_WANT_AVGLAMDA)
                //    DEBUG('*',"\nSHAKE: avgLambda= %.2f, maxiLambda= %d, bestLg=%d -> %d",
                //            (float)avgLambda/clauseNum, maxiLambda, bestLg, Lg);
            }

        } // End of TH_USE_PERORIODIC_SHAKE

        else if (TH_USE_DIV_TO_MAINTAIN_AVG)
        {
            if (steps%TH_SHAKE_In_AVG EQ (TH_SHAKE_In_AVG-1))
            {
                int avgLambda,maxiLambda;
                steps=0;

                avgLambda=0;

                for (i=1;i<=clauseNum;i++)
                    avgLambda+=lambda[i];

                if (avgLambda>(float)TH_MAX_AVG*clauseNum)
                {
                    avgLambda=maxiLambda=0;
                    for (i=1;i<=clauseNum;i++)
                    {
                        newLambda=max(1,lambda[i]/TH_DECREASE_FACTOR_IN_AVG);

                        if(TH_WANT_AVGLAMDA)
                        {
                            avgLambda+=newLambda;
                            maxiLambda=max(newLambda,maxiLambda);
                        }

                        if (newLambda!=lambda[i])
                            ChangeLambda(i,newLambda); 
                    } 

                    //if(TH_WANT_AVGLAMDA)
                    //    DEBUG('*',"\nDivToMaintainAvg: avgLambda= %.2f, maxiLambda= %d, bestLg=%d -> %d",
                    //            (float)avgLambda/clauseNum, maxiLambda, bestLg, Lg);
                    bestLg=Lg;
                }
            }
        } // end of TH_USE_DIV_TO_MAINTAIN_AVG

        else if (TH_USE_DEC_TO_MAINTAIN_AVG)
        {
            if (steps%TH_SHAKE_In_AVG EQ (TH_SHAKE_In_AVG-1))
            {
                int avgLambda,maxiLambda;
                steps=0;

                avgLambda=0;

                for (i=1;i<=clauseNum;i++)
                    avgLambda+=lambda[i];

                if (avgLambda>(float)TH_MAX_AVG*clauseNum)
                {
                    avgLambda=maxiLambda=0;
                    for (i=1;i<=clauseNum;i++)
                    {
                        newLambda=max(1,lambda[i]-TH_DECREASE_FACTOR_IN_AVG);

                        avgLambda+=newLambda;
                        maxiLambda=max(newLambda,maxiLambda);

                        ChangeLambda(i,newLambda); 
                    } 
                    //if(TH_WANT_AVGLAMDA)
                    //    DEBUG('*',"\nDecToMaintainAvg: avgLambda= %.2f, maxiLambda= %d, bestLg=%d -> %d",
                    //            (float)avgLambda/clauseNum, maxiLambda, bestLg, Lg);
                    bestLg=Lg;
                }
            }
        } // end of TH_USE_DEC_TO_MAINTAIN_AVG
    }/*End of while*/ 

    if (falseClauseNum !=0 )
    {
        fprintf(newfp,"\nRound %d finished!",roundNum);
        fflush(newfp);
        roundNum++;
        totalFlipTime=0;
        if (roundNum<TH_ROUND)
            goto nextRound;
    }

    get_cpu_time(&endUser,&endSys);
    printf("\nCPU time consumed (not elapsed wall clock time) is %.3f sec\n",
            endUser-startUser+endSys-startSys);

    secondsUsed=(float)endUser-startUser+endSys-startSys;

#ifdef WANT_DEBUG
    printf("\nTotal time used %20.10f in s, user time %f, sys time %f ",
            secondsUsed, endUser-startUser,endSys-startSys);
    DEBUG('*',"\nAfter flip, # is %d, the best is %d",falseClauseNum,bestClauseNum);

    /*
        evilFile=fopen("evil-clauses","w");
        for (i=1;i<=clauseNum;i++)
        fprintf(evilFile,"%d ID %d , (%d, ..., %d)\n",clauseWeight[i],i,
        absClause[i][1],absClause[i][clauseLen[i]]);
        fflush(evilFile);
     */
#endif

    ASSERT(bug EQ 1);

    if (CheckSolution() EQ TRUE)
        OutputSolution(argv[3],argv[1],TH_START_RUN+runs);

    roundNum=0;

    //    if (runs<TH_RUNS-1)
    //    goto startAgain;
    if (falseClauseNum == 0) 
        return 1;
    else
        return 0;
}/*End of Search() */
