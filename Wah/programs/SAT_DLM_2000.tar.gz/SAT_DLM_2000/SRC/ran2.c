/*
 * Copyright (C) 2000, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */
/*
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- 
#  Author: Zhe Wu, University of Illinois              |
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*/

#include <stdio.h>
#include "utility.h"

/* Random Number Generator */

#ifndef _ran2_h
        #define _ran2_h
    #define IM1 2147483563
    #define IM2 2147483399
    #define AM (1.0/IM1)
    #define IMM1 (IM1-1)
    #define IA1 40014
    #define IA2 40692
    #define IQ1 53688
    #define IQ2 52774
    #define IR1 12211
    #define IR2 3791
    #define NTAB 32
    #define NDIV (1+IMM1/NTAB)
    #define EPS 1.2e-7
    #define RNMX (1.0-EPS)
#endif


/* Long period (> 2*10^18) random number generator of 
   L'Ecuyer with Bays-Durham shuffle and added safeguards.
   Returns a uniform random deviate between 0.0 and 1.0
   (exclusive of the endpoint values). Call with  idum
   a negative integer to initialize; thereafter, do not
   alter idum between succesive deviates in a sequence.
   RNMX should approximate the largest floating value
   that is less than 1 */

float ran2(long *idum) {

    int j;
    long k;
    static long idum2=123456789;
    static long iy=0;
    static long iv[NTAB];
    float temp;

    if(*idum <= 0) {  /* initialize */
        if(-(*idum)< 1) *idum=1;  /* be sure to prevent
                         idum=0 */
        else *idum = -(*idum);
        idum2=(*idum);
        for(j=NTAB+7;j>=0;j--) { /* load the shuffle table
                        (after 8 warm-ups )*/
            k=(*idum)/IQ1;
            *idum=IA1*(*idum-k*IQ1)-k*IR1;
            if(*idum<0) *idum += IM1;
            if(j<NTAB) iv[j] = *idum;
        }
        iy = iv[0];
    }

    k=(*idum)/IQ1;  /* start here when not initializing */
    *idum=IA1*(*idum-k*IQ1)-k*IR1;  /* compute idum=(IA1*idum)%IM1
                   without overflows by    Schrage's method */
    if(*idum<0) *idum += IM1;
    k=idum2/IQ2;
    idum2=IA2*(idum2-k*IQ2)-k*IR2; /* idum=(IA2*idum)%IM2 likewise */
    if(idum2<0) idum2 +=IM2;
    j=iy/NDIV;        /* will be in the range 0..NTAB-1 */
    iy=iv[j]-idum2;        /* here idum is shuffled, idum and idum2
                  are combined to generate output */
    iv[j] = *idum;
    if(iy<1) iy += IMM1;
    if((temp=AM*iy) > RNMX ) return RNMX; /*because users do not
                  expect endpoint values */
    else return temp;

}

