/*
 * Copyright (C) 2000, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */
/*
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- 
#  Author: Zhe Wu, University of Illinois              |
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*/

#include <stdio.h>
#include "public.h"
#include "utility.h"

/*
   this seems to be dependent on how the compiler is configured.
   if you have problems with va_start, try both of these alternatives
*/

#define HOST_SNAKE

#ifdef HOST_SNAKE
#include <stdarg.h>
#else
#ifdef HOST_SPARC
#include <stdarg.h>
#else
#include "/usr/include/stdarg.h"
#endif
#endif

static char *enableFlags = NULL; /* controls which DEBUG messages are printed */

/*
   ----------------------------------------------------------------------
   DebugInit
      Initialize so that only DEBUG messages with a flag in flagList
      will be printed.

      If the flag is "+", we enable all DEBUG messages.

      "flagList" is a string of characters for whose DEBUG messages are
              to be enabled.
   ----------------------------------------------------------------------
*/

void DebugInit(char *flagList)
{
    enableFlags = flagList;
}

/*
   ----------------------------------------------------------------------
   DebugIsEnabled
      Return TRUE if DEBUG messages with "flag" are to be printed.
   ----------------------------------------------------------------------
*/

bool DebugIsEnabled(char flag)
{
    if (enableFlags != NULL)
       return (strchr(enableFlags, flag) != 0)
                || (strchr(enableFlags, '+') != 0);
    else
      return FALSE;
}

/*
----------------------------------------------------------------------
 DEBUG
      Print a debug message, if flag is enabled.  Like printf,
      only with an extra argument on the front.
---------------------------------------------------------------------- 
*/

void DEBUG(char flag, char *format, ...)
{
#ifdef WANT_DEBUG
      if (DebugIsEnabled(flag) || flag EQ '*')
        { 
        va_list ap;
        /* You will get an unused variable message here -- ignore it. */
        va_start(ap, format);
        vfprintf(stdout, format, ap);
        va_end(ap);
        fflush(stdout);
        }
#endif
}

void ERROR(char *format, ...)
{
    va_list ap;
    /* You will get an unused variable message here -- ignore it. */
    va_start(ap, format);
    vfprintf(stdout, format, ap);
    va_end(ap);
    fflush(stdout);
    exit(1);
}

int  max(int x, int y)
{
   if (x>y)
       return x;
   else
       return y;
}

int  min(int x, int y)
{
   if (x>y)
       return y;
   else
       return x;
}

