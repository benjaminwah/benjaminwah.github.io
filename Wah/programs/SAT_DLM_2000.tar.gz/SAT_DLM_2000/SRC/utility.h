/*
 * Copyright (C) 2000, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */
/*
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- 
#  Author: Zhe Wu, University of Illinois              |
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*/

#ifndef UTILITY_H
#define UTILITY_H

typedef enum 
   {FALSE,TRUE} bool;

#define S_INT (sizeof(int))
#define S_CHAR (sizeof(char))

#ifndef EQ
#define EQ ==
#endif

#ifndef Forever
#define Forever while(1)
#endif
 
/* Interface to debugging routines. */

extern void DebugInit(char * flags);  /* enable printing debug messages */

extern bool DebugIsEnabled(char flag);  /* Is this debug flag enabled? */

extern void DEBUG (char flag, char * format, ...); /* Print debug message */
                                                /* if flag is enabled */
extern void ERROR(char *format, ...);

extern int  max(int x, int y);

extern int  min(int x, int y);

extern float ran2(long *idum);

/*
   ----------------------------------------------------------------------
   ASSERT
        If condition is false,  print a message and dump core.
        Useful for documenting assumptions in the code.
  
        NOTE: needs to be a #define, to be able to print the location
        where the error occurred.
  ----------------------------------------------------------------------
*/

#define ASSERT(condition)                                                     \
    if (!(condition)) {                                                       \
        fprintf(stderr, "Assertion failed: line %d, file \"%s\"\n",           \
                __LINE__, __FILE__);                                          \
        fflush(stderr);                                                       \
        exit(1);                                                              \
    }

#endif
