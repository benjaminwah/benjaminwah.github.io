/*
 * Copyright (C) 2000, Board of Trustees of the University of Illinois.
 *
 * Permission is granted to copy and distribute source with out fee.
 * Commercialization of this product requires prior licensing from the
 * University of Illinois.  Commercialization includes the integration of this 
 * code in part or whole into a product for resale.  Free distribution of 
 * unmodified source and use of this software is not considered 
 * commercialization.
 *
 */
/*
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- 
#  Author: Zhe Wu, University of Illinois              |
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*/

/* for cpu timing uses getrusage() unless TIMES is defined */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#undef TIMES


#ifdef TIMES
#include <sys/tupes.h>
#include <sys/times.h>
#include <sys/param.h>

#ifndef HZ
#define HZ       60.0
#endif

#else
#include <sys/time.h>
#include <sys/resource.h>

#endif

void get_cpu_time(double *usertime, double *systime);

void report_cpu(FILE *fp, char *str)
{
    static call_no = 0;
    double utime, stime;

    get_cpu_time(&utime, &stime);

    if ( str == NULL )
    {
        if ( call_no++ == 0 )
            fprintf(fp,"Preprocessing");
        else
            fprintf(fp,"Total CPU");
    }
    else
        fprintf(fp,"%s", str);

    fprintf(fp," time:\t%2.2fu  %2.2fs\t%2.2f (sec)\n", utime, stime,
            utime + stime);
}


void get_cpu_time(double *usertime, double *systime)
{
#ifdef TIMES
    struct tms time;

    times( &time );

    *usertime = (double)time.tms_utime / (double)HZ;
    *systime  = (double)time.tms_stime / (double)HZ;
#else

    struct rusage usage;

    getrusage( RUSAGE_SELF, &usage );

    *usertime = (double)usage.ru_utime.tv_sec +
        (double)usage.ru_utime.tv_usec / 1000000.;
    *systime = (double)usage.ru_stime.tv_sec +
        (double)usage.ru_stime.tv_usec / 1000000.;
#endif

}

/*
void main()
{
    long i,j,k;
    double startUser,endUser,startSys,endSys;

    report_cpu(stdout, "Sleep1");
    printf("\n\nFirst, sleep 1 second\n");
    sleep(1);
    report_cpu(stdout, "Sleep1");

    printf("\n\nSecond, test some computation\n");
    report_cpu(stdout, "test1");
    j=197;
    for (k=1;k<100;k++)
        for (i=0;i<100000;i++)
            j=(j*j%1798)*19999+i*k;

    printf("%d\n",j);
    report_cpu(stdout, "test1");

    printf("\n\nThird, show user cpu time + system cpu time consumed\n");
    get_cpu_time(&startUser,&startSys);
    {
        j=197;
        for (k=1;k<100;k++)
            for (i=0;i<100000;i++)
                j=(j*j%1798)*19999+i*k;
        printf("%d\n",j);
    }
    get_cpu_time(&endUser,&endSys);
    printf("\nCPU time consumed (not elapsed wall clock time) is %.3f sec\n",
        endUser-startUser+endSys-startSys);
}
*/
